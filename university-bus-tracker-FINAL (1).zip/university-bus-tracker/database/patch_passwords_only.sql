-- ============================================================
-- PASSWORD PATCH SCRIPT
-- Run this if your database already exists and you don't want
-- to drop and re-create it. This ONLY updates the passwords.
--
-- All passwords are set to: password123
-- ============================================================

USE university_bus_tracker;

-- ── BUG FIX #2: Add is_active column to admins if it doesn't exist
ALTER TABLE admins 
  ADD COLUMN IF NOT EXISTS is_active BOOLEAN NOT NULL DEFAULT TRUE;

-- ── BUG FIX #1: Fix admin passwords ──────────────────────────
UPDATE admins SET password = '$2b$10$B4aYO1kK6ZUwr9Pcpva16OnwN3CYCI6AzvQ8mhtq/46AePRoQGMj6'
    WHERE email = 'admin@university.edu';
UPDATE admins SET password = '$2b$10$ERSuN0Z8VQkwx0Y8xobWdOe9GsL44oBW.Y3rUSKi6QeqWFh1K.W3m'
    WHERE email = 'manager@university.edu';

-- ── BUG FIX #1: Fix driver passwords ─────────────────────────
UPDATE drivers SET password = '$2b$10$B2XGPcZjOWVNVvTKFKst.unb7tXY3Yh95DrmX5fKh7E6pDy0F1lKu'
    WHERE email = 'driver1@university.edu';
UPDATE drivers SET password = '$2b$10$hMNh3mdVSyqtdysOmqnAo.RIL4QThOJTfa3XiZvvleXO9o6DWUbtS'
    WHERE email = 'driver2@university.edu';
UPDATE drivers SET password = '$2b$10$4p2WsrE2fLOCVBbxnvhWwOmI7oq0hZdzNVgUKVADbkxWcky1nfEH6'
    WHERE email = 'driver3@university.edu';
UPDATE drivers SET password = '$2b$10$MJUYLrasa1PN4hv0BvcS.uqkTzLrs7qVzBkwQrDHy5x1DehhYDahS'
    WHERE email = 'driver4@university.edu';
UPDATE drivers SET password = '$2b$10$N0uNrey2HVup0a07M9y5seTpZS2rnGIW/SbF8ZM8X22oxRZfSXcBC'
    WHERE email = 'driver5@university.edu';
UPDATE drivers SET password = '$2b$10$NnZzDeEOZvqncKjxky5svOEoI//K10E.wjsd9oSc/IwJwHBbQuv9S'
    WHERE email = 'driver6@university.edu';
UPDATE drivers SET password = '$2b$10$4J3QF61neUxdcJ4uSm54ZezkFCTqtIAoR52.N02Nt9AtomNUINiR6'
    WHERE email = 'driver7@university.edu';
UPDATE drivers SET password = '$2b$10$e8Y5rgG0TuuwT2JWFK6Zf./Y7y/0mW3BZhb3dzBjQqD0G9axDoA5e'
    WHERE email = 'driver8@university.edu';

-- ── BUG FIX #1: Fix student passwords ────────────────────────
-- (Only needed if students came from schema.sql, not self-registration)
UPDATE students SET password = '$2b$10$w7BNRSFtDZqhhSJUu/LFWePNw5TPhcXWG.mA4w1X60DULhCdDzy/e'
    WHERE email = 'ali@student.edu';
UPDATE students SET password = '$2b$10$3BeQUYOsfizlOSDl.zhYQ.IjEmR31do/3ShE.a5n/qhQqGe5.IlEm'
    WHERE email = 'sara@student.edu';
UPDATE students SET password = '$2b$10$4Vcmo3SxlbP9hWlNZY4mVuGLmHZyyymbIWGaFQiQmyPXeZTZxz9Ha'
    WHERE email = 'hassan@student.edu';
UPDATE students SET password = '$2b$10$KhMXQiB46xOciEhRIz3lHu.WWhncmDrx5faQCjhxk1F8tpr4fVWo6'
    WHERE email = 'fatima@student.edu';
UPDATE students SET password = '$2b$10$es/2V5pc49SUzVX1e0p1fOETKOnWaIyvp52c8amXQxYVrudypS8GG'
    WHERE email = 'zara@student.edu';

SELECT 'Password patch applied successfully. All passwords are now: password123' AS result;
