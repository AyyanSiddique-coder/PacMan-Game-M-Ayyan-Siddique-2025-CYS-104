-- ============================================================
-- UNIVERSITY BUS TRACKING SYSTEM - MySQL Schema
-- ============================================================
-- Run this script in MySQL to set up the entire database.
-- Command: mysql -u root -p < schema.sql
-- ============================================================

-- Create and select the database
CREATE DATABASE IF NOT EXISTS university_bus_tracker
    CHARACTER SET utf8mb4
    COLLATE utf8mb4_unicode_ci;

USE university_bus_tracker;

-- ============================================================
-- TABLE: admins
-- ============================================================
CREATE TABLE admins (
    id          BIGINT AUTO_INCREMENT PRIMARY KEY,
    name        VARCHAR(100)        NOT NULL,
    email       VARCHAR(150)        NOT NULL UNIQUE,
    password    VARCHAR(255)        NOT NULL,   -- BCrypt hashed
    phone       VARCHAR(20),
    role        VARCHAR(30)         NOT NULL DEFAULT 'ROLE_ADMIN',
    is_active   BOOLEAN             NOT NULL DEFAULT TRUE,          -- BUG FIX #2: added is_active
    created_at  DATETIME            NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at  DATETIME            NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- ============================================================
-- TABLE: students
-- ============================================================
CREATE TABLE students (
    id              BIGINT AUTO_INCREMENT PRIMARY KEY,
    name            VARCHAR(100)    NOT NULL,
    email           VARCHAR(150)    NOT NULL UNIQUE,
    password        VARCHAR(255)    NOT NULL,
    student_id      VARCHAR(50)     UNIQUE,
    phone           VARCHAR(20),
    department      VARCHAR(100),
    role            VARCHAR(30)     NOT NULL DEFAULT 'ROLE_STUDENT',
    is_active       BOOLEAN         NOT NULL DEFAULT TRUE,
    created_at      DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at      DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- ============================================================
-- TABLE: routes
-- ============================================================
CREATE TABLE routes (
    id              BIGINT AUTO_INCREMENT PRIMARY KEY,
    route_name      VARCHAR(150)    NOT NULL,
    route_code      VARCHAR(20)     NOT NULL UNIQUE,
    description     TEXT,
    start_location  VARCHAR(200)    NOT NULL,
    end_location    VARCHAR(200)    NOT NULL,
    total_distance  DECIMAL(8,2),
    estimated_time  INT,
    is_active       BOOLEAN         NOT NULL DEFAULT TRUE,
    created_at      DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at      DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- ============================================================
-- TABLE: route_stops
-- ============================================================
CREATE TABLE route_stops (
    id              BIGINT AUTO_INCREMENT PRIMARY KEY,
    route_id        BIGINT          NOT NULL,
    stop_name       VARCHAR(150)    NOT NULL,
    stop_sequence   INT             NOT NULL,
    latitude        DECIMAL(10,8),
    longitude       DECIMAL(11,8),
    FOREIGN KEY (route_id) REFERENCES routes(id) ON DELETE CASCADE
);

-- ============================================================
-- TABLE: buses
-- ============================================================
CREATE TABLE buses (
    id              BIGINT AUTO_INCREMENT PRIMARY KEY,
    bus_number      VARCHAR(50)     NOT NULL UNIQUE,
    number_plate    VARCHAR(30)     NOT NULL UNIQUE,
    capacity        INT             NOT NULL DEFAULT 40,
    bus_model       VARCHAR(100),
    status          ENUM('ACTIVE','INACTIVE','MAINTENANCE') NOT NULL DEFAULT 'ACTIVE',
    route_id        BIGINT,
    created_at      DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at      DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (route_id) REFERENCES routes(id) ON DELETE SET NULL
);

-- ============================================================
-- TABLE: drivers
-- ============================================================
CREATE TABLE drivers (
    id              BIGINT AUTO_INCREMENT PRIMARY KEY,
    name            VARCHAR(100)    NOT NULL,
    email           VARCHAR(150)    NOT NULL UNIQUE,
    password        VARCHAR(255)    NOT NULL,
    phone           VARCHAR(20),
    license_number  VARCHAR(50)     UNIQUE,
    role            VARCHAR(30)     NOT NULL DEFAULT 'ROLE_DRIVER',
    bus_id          BIGINT,
    is_active       BOOLEAN         NOT NULL DEFAULT TRUE,
    created_at      DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at      DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (bus_id) REFERENCES buses(id) ON DELETE SET NULL
);

-- ============================================================
-- TABLE: trips
-- ============================================================
CREATE TABLE trips (
    id              BIGINT AUTO_INCREMENT PRIMARY KEY,
    driver_id       BIGINT          NOT NULL,
    bus_id          BIGINT          NOT NULL,
    route_id        BIGINT          NOT NULL,
    status          ENUM('STARTED','IN_PROGRESS','COMPLETED','CANCELLED') NOT NULL DEFAULT 'STARTED',
    start_time      DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP,
    end_time        DATETIME,
    notes           TEXT,
    created_at      DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (driver_id) REFERENCES drivers(id),
    FOREIGN KEY (bus_id)    REFERENCES buses(id),
    FOREIGN KEY (route_id)  REFERENCES routes(id)
);

-- ============================================================
-- TABLE: bus_locations
-- ============================================================
CREATE TABLE bus_locations (
    id              BIGINT AUTO_INCREMENT PRIMARY KEY,
    bus_id          BIGINT          NOT NULL,
    trip_id         BIGINT,
    latitude        DECIMAL(10,8)   NOT NULL,
    longitude       DECIMAL(11,8)   NOT NULL,
    speed           DECIMAL(6,2),
    heading         DECIMAL(5,2),
    accuracy        DECIMAL(8,2),
    recorded_at     DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (bus_id)  REFERENCES buses(id),
    FOREIGN KEY (trip_id) REFERENCES trips(id) ON DELETE SET NULL,
    INDEX idx_bus_recorded (bus_id, recorded_at DESC)
);

-- ============================================================
-- TABLE: notifications
-- ============================================================
CREATE TABLE notifications (
    id              BIGINT AUTO_INCREMENT PRIMARY KEY,
    title           VARCHAR(200)    NOT NULL,
    message         TEXT            NOT NULL,
    recipient_role  VARCHAR(30),
    is_read         BOOLEAN         NOT NULL DEFAULT FALSE,
    created_at      DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP
);

-- ============================================================
-- SAMPLE DATA - Admins
-- !!  BUG FIX #1: All passwords below are correct BCrypt hashes
--     of "password123", verified with BCryptPasswordEncoder.
--     The original hashes were WRONG and caused 401 for all logins.
-- ============================================================
INSERT INTO admins (name, email, password, phone, role, is_active) VALUES
('Super Admin',    'admin@university.edu',   '$2b$10$B4aYO1kK6ZUwr9Pcpva16OnwN3CYCI6AzvQ8mhtq/46AePRoQGMj6', '0300-1234567', 'ROLE_ADMIN', TRUE),
('System Manager', 'manager@university.edu', '$2b$10$ERSuN0Z8VQkwx0Y8xobWdOe9GsL44oBW.Y3rUSKi6QeqWFh1K.W3m', '0301-2345678', 'ROLE_ADMIN', TRUE);

-- ============================================================
-- SAMPLE DATA - Routes (Lahore University Routes)
-- ============================================================
INSERT INTO routes (route_name, route_code, description, start_location, end_location, total_distance, estimated_time) VALUES
('Gulberg to Campus',          'R-01', 'Main Gulberg route via Mall Road',         'Gulberg III, Lahore',        'University Main Gate', 12.5, 35),
('DHA to Campus',              'R-02', 'Defence Housing Authority route',           'DHA Phase 5, Lahore',        'University Main Gate', 18.0, 45),
('Model Town to Campus',       'R-03', 'Model Town via Ferozepur Road',             'Model Town, Lahore',         'University Main Gate', 10.0, 30),
('Johar Town to Campus',       'R-04', 'Johar Town route',                          'Johar Town, Lahore',         'University Main Gate', 8.5,  25),
('Bahria Town to Campus',      'R-05', 'Bahria Town via Ring Road',                 'Bahria Town, Lahore',        'University Main Gate', 22.0, 55),
('Allama Iqbal Town to Campus','R-06', 'Allama Iqbal Town route',                   'Allama Iqbal Town, Lahore',  'University Main Gate', 14.0, 40),
('Wapda Town to Campus',       'R-07', 'Wapda Town via Canal Bank Road',            'Wapda Town, Lahore',         'University Main Gate', 11.0, 32),
('Garden Town to Campus',      'R-08', 'Garden Town route',                         'Garden Town, Lahore',        'University Main Gate', 9.0,  28);

-- ============================================================
-- SAMPLE DATA - Route Stops
-- ============================================================
INSERT INTO route_stops (route_id, stop_name, stop_sequence, latitude, longitude) VALUES
(1, 'Gulberg Main Market',     1, 31.5204, 74.3587),
(1, 'Liberty Market',          2, 31.5225, 74.3502),
(1, 'Kalma Chowk',             3, 31.5196, 74.3354),
(1, 'Mall Road Crossing',      4, 31.5497, 74.3436),
(1, 'University Main Gate',    5, 31.4804, 74.3162),

(2, 'DHA Phase 5 Entrance',    1, 31.4719, 74.4053),
(2, 'Cavalry Ground',          2, 31.5028, 74.3983),
(2, 'Cantt Station',           3, 31.5577, 74.3746),
(2, 'University Main Gate',    4, 31.4804, 74.3162),

(3, 'Model Town Park',         1, 31.4822, 74.3278),
(3, 'Ferozepur Road Chowk',    2, 31.4907, 74.3196),
(3, 'University Main Gate',    3, 31.4804, 74.3162);

-- ============================================================
-- SAMPLE DATA - Buses
-- ============================================================
INSERT INTO buses (bus_number, number_plate, capacity, bus_model, status, route_id) VALUES
('UNI-001', 'LHR-0001', 45, 'Hino Bus 2020',    'ACTIVE', 1),
('UNI-002', 'LHR-0002', 45, 'Hino Bus 2020',    'ACTIVE', 2),
('UNI-003', 'LHR-0003', 40, 'Isuzu NQR 2019',   'ACTIVE', 3),
('UNI-004', 'LHR-0004', 40, 'Isuzu NQR 2019',   'ACTIVE', 4),
('UNI-005', 'LHR-0005', 50, 'Yutong Bus 2021',  'ACTIVE', 5),
('UNI-006', 'LHR-0006', 50, 'Yutong Bus 2021',  'ACTIVE', 6),
('UNI-007', 'LHR-0007', 40, 'Hino Bus 2018',    'ACTIVE', 7),
('UNI-008', 'LHR-0008', 40, 'Hino Bus 2018',    'ACTIVE', 8),
('UNI-009', 'LHR-0009', 45, 'Isuzu NQR 2022',   'INACTIVE', NULL),
('UNI-010', 'LHR-0010', 45, 'Isuzu NQR 2022',   'MAINTENANCE', NULL);

-- ============================================================
-- SAMPLE DATA - Drivers
-- !! BUG FIX #1: Correct BCrypt hashes for "password123"
-- ============================================================
INSERT INTO drivers (name, email, password, phone, license_number, bus_id) VALUES
('Muhammad Ali',     'driver1@university.edu', '$2b$10$B2XGPcZjOWVNVvTKFKst.unb7tXY3Yh95DrmX5fKh7E6pDy0F1lKu', '0311-1111111', 'LIC-001', 1),
('Ahmed Hassan',     'driver2@university.edu', '$2b$10$hMNh3mdVSyqtdysOmqnAo.RIL4QThOJTfa3XiZvvleXO9o6DWUbtS', '0311-2222222', 'LIC-002', 2),
('Bilal Khan',       'driver3@university.edu', '$2b$10$4p2WsrE2fLOCVBbxnvhWwOmI7oq0hZdzNVgUKVADbkxWcky1nfEH6', '0311-3333333', 'LIC-003', 3),
('Usman Tariq',      'driver4@university.edu', '$2b$10$MJUYLrasa1PN4hv0BvcS.uqkTzLrs7qVzBkwQrDHy5x1DehhYDahS', '0311-4444444', 'LIC-004', 4),
('Kamran Sheikh',    'driver5@university.edu', '$2b$10$N0uNrey2HVup0a07M9y5seTpZS2rnGIW/SbF8ZM8X22oxRZfSXcBC', '0311-5555555', 'LIC-005', 5),
('Zubair Ahmed',     'driver6@university.edu', '$2b$10$NnZzDeEOZvqncKjxky5svOEoI//K10E.wjsd9oSc/IwJwHBbQuv9S', '0311-6666666', 'LIC-006', 6),
('Imran Butt',       'driver7@university.edu', '$2b$10$4J3QF61neUxdcJ4uSm54ZezkFCTqtIAoR52.N02Nt9AtomNUINiR6', '0311-7777777', 'LIC-007', 7),
('Shahid Malik',     'driver8@university.edu', '$2b$10$e8Y5rgG0TuuwT2JWFK6Zf./Y7y/0mW3BZhb3dzBjQqD0G9axDoA5e', '0311-8888888', 'LIC-008', 8);

-- ============================================================
-- SAMPLE DATA - Students
-- !! BUG FIX #1: Correct BCrypt hashes for "password123"
-- ============================================================
INSERT INTO students (name, email, password, student_id, phone, department) VALUES
('Ali Raza',         'ali@student.edu',     '$2b$10$w7BNRSFtDZqhhSJUu/LFWePNw5TPhcXWG.mA4w1X60DULhCdDzy/e', 'CS-2021-001', '0321-1111111', 'Computer Science'),
('Sara Khan',        'sara@student.edu',    '$2b$10$3BeQUYOsfizlOSDl.zhYQ.IjEmR31do/3ShE.a5n/qhQqGe5.IlEm', 'EE-2021-002', '0321-2222222', 'Electrical Engineering'),
('Hassan Malik',     'hassan@student.edu',  '$2b$10$4Vcmo3SxlbP9hWlNZY4mVuGLmHZyyymbIWGaFQiQmyPXeZTZxz9Ha', 'ME-2022-003', '0321-3333333', 'Mechanical Engineering'),
('Fatima Zahra',     'fatima@student.edu',  '$2b$10$KhMXQiB46xOciEhRIz3lHu.WWhncmDrx5faQCjhxk1F8tpr4fVWo6', 'CS-2022-004', '0321-4444444', 'Computer Science'),
('Zara Ahmed',       'zara@student.edu',    '$2b$10$es/2V5pc49SUzVX1e0p1fOETKOnWaIyvp52c8amXQxYVrudypS8GG', 'BBA-2021-005','0321-5555555', 'Business Administration');

-- ============================================================
-- SAMPLE DATA - Notifications
-- ============================================================
INSERT INTO notifications (title, message, recipient_role) VALUES
('System Online',           'The University Bus Tracking System is now live.',                               NULL),
('New Route Added',         'Route R-08 (Garden Town to Campus) has been added.',                           'ROLE_STUDENT'),
('Driver Reminder',         'Please start your trip only when you are at the designated starting point.',    'ROLE_DRIVER'),
('Maintenance Alert',       'Bus UNI-010 is under maintenance until further notice.',                        'ROLE_STUDENT');
