package com.university.bustracker.config;

import com.university.bustracker.security.JwtAuthenticationFilter;
import com.university.bustracker.service.CustomUserDetailsService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpMethod;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.dao.DaoAuthenticationProvider;
import org.springframework.security.config.annotation.authentication.configuration.AuthenticationConfiguration;
import org.springframework.security.config.annotation.method.configuration.EnableMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configurers.AbstractHttpConfigurer;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;
import org.springframework.web.cors.CorsConfiguration;
import org.springframework.web.cors.CorsConfigurationSource;
import org.springframework.web.cors.UrlBasedCorsConfigurationSource;

import java.util.Arrays;
import java.util.List;

/**
 * SecurityConfig.java
 * ====================
 * The central Spring Security configuration.
 * This defines:
 * 1. Which endpoints are public vs. protected
 * 2. Which roles can access which endpoints
 * 3. JWT authentication setup
 * 4. Password encoding
 * 5. CORS settings
 * 6. CSRF settings
 *
 * @Configuration: Tells Spring this class has bean definitions (@Bean methods).
 * @EnableWebSecurity: Activates Spring Security for this application.
 * @EnableMethodSecurity: Enables @PreAuthorize on individual controller methods.
 */
@Configuration
@EnableWebSecurity
@EnableMethodSecurity(prePostEnabled = true)
public class SecurityConfig {

    @Autowired
    private CustomUserDetailsService userDetailsService;

    @Autowired
    private JwtAuthenticationFilter jwtAuthenticationFilter;

    /**
     * BCryptPasswordEncoder Bean.
     *
     * BCrypt is a hashing algorithm designed for passwords.
     * Unlike MD5 or SHA-256, BCrypt:
     * - Is intentionally SLOW (prevents brute force attacks)
     * - Includes a random SALT (prevents rainbow table attacks)
     * - Has a configurable cost factor (strength = 12 means 2^12 rounds)
     *
     * BCrypt hash of "password123" looks like:
     * $2a$12$LQv3c1yqBWVHxkd0LHAkCO...
     *
     * @Bean: This method returns a bean that Spring manages.
     * Any class that @Autowires PasswordEncoder gets this BCrypt instance.
     */
    @Bean
    public PasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder(12);  // 12 = strength factor
    }

    /**
     * DaoAuthenticationProvider Bean.
     * Connects Spring Security's authentication system to our:
     * - Custom UserDetailsService (loads users from DB)
     * - BCryptPasswordEncoder (verifies passwords)
     */
    @Bean
    public DaoAuthenticationProvider authenticationProvider() {
        DaoAuthenticationProvider authProvider = new DaoAuthenticationProvider();
        authProvider.setUserDetailsService(userDetailsService);
        authProvider.setPasswordEncoder(passwordEncoder());
        return authProvider;
    }

    /**
     * AuthenticationManager Bean.
     * The AuthenticationManager is the coordinator that:
     * - Takes a username + password
     * - Delegates to the DaoAuthenticationProvider
     * - Returns an Authentication object if credentials are correct
     *
     * We expose it as a @Bean so AuthService can autowire it for login.
     */
    @Bean
    public AuthenticationManager authenticationManager(
            AuthenticationConfiguration authConfig) throws Exception {
        return authConfig.getAuthenticationManager();
    }

    /**
     * CORS Configuration Bean.
     * CORS = Cross-Origin Resource Sharing.
     *
     * By default, browsers block requests from different origins.
     * Since our HTML is served from http://localhost:8080 and the API
     * is also at http://localhost:8080, this is usually fine.
     *
     * If you deploy the frontend on a different server (e.g. Netlify),
     * add that URL to allowedOrigins.
     */
    @Bean
    public CorsConfigurationSource corsConfigurationSource() {
        CorsConfiguration configuration = new CorsConfiguration();
        configuration.setAllowedOrigins(List.of("*"));  // Allow all origins (adjust for prod)
        configuration.setAllowedMethods(Arrays.asList("GET", "POST", "PUT", "DELETE", "OPTIONS"));
        configuration.setAllowedHeaders(Arrays.asList("Authorization", "Content-Type", "Accept"));
        configuration.setExposedHeaders(List.of("Authorization"));

        UrlBasedCorsConfigurationSource source = new UrlBasedCorsConfigurationSource();
        source.registerCorsConfiguration("/**", configuration);  // Apply to all paths
        return source;
    }

    /**
     * Security Filter Chain — THE MOST IMPORTANT METHOD.
     * Defines what is allowed and what requires authentication.
     *
     * Rules are evaluated TOP TO BOTTOM. First match wins.
     */
    @Bean
    public SecurityFilterChain filterChain(HttpSecurity http) throws Exception {
        http
            // CSRF (Cross-Site Request Forgery) protection:
            // We disable it because JWT is stateless. CSRF protection is
            // needed for session-based auth (cookies), not JWTs.
            .csrf(AbstractHttpConfigurer::disable)

            // Enable CORS with our configuration above
            .cors(cors -> cors.configurationSource(corsConfigurationSource()))

            // Session management: STATELESS means Spring will NOT create
            // HTTP sessions. Every request must include a JWT.
            .sessionManagement(session ->
                session.sessionCreationPolicy(SessionCreationPolicy.STATELESS)
            )

            // Authorization rules: who can access what
            .authorizeHttpRequests(auth -> auth

                // ─── PUBLIC ENDPOINTS (no token required) ───────────────
                // Login and registration
                .requestMatchers("/api/auth/**").permitAll()

                // Static frontend files (HTML, CSS, JS)
                .requestMatchers("/", "/index.html", "/login.html").permitAll()
                .requestMatchers("/student-dashboard.html").permitAll()
                .requestMatchers("/driver-dashboard.html").permitAll()
                .requestMatchers("/admin-dashboard.html").permitAll()
                .requestMatchers("/css/**", "/js/**", "/images/**").permitAll()

                // Public bus/route viewing (students can view without login)
                .requestMatchers(HttpMethod.GET, "/api/buses/**").permitAll()
                .requestMatchers(HttpMethod.GET, "/api/routes/**").permitAll()
                .requestMatchers(HttpMethod.GET, "/api/location/**").permitAll()

                // ─── STUDENT ENDPOINTS ───────────────────────────────────
                .requestMatchers("/api/student/**").hasRole("STUDENT")

                // ─── DRIVER ENDPOINTS ────────────────────────────────────
                .requestMatchers("/api/driver/**").hasRole("DRIVER")
                .requestMatchers(HttpMethod.POST, "/api/location/update").hasRole("DRIVER")
                .requestMatchers("/api/trips/start").hasRole("DRIVER")
                .requestMatchers("/api/trips/end/**").hasRole("DRIVER")

                // ─── ADMIN ENDPOINTS ─────────────────────────────────────
                .requestMatchers("/api/admin/**").hasRole("ADMIN")
                .requestMatchers(HttpMethod.POST, "/api/buses/**").hasRole("ADMIN")
                .requestMatchers(HttpMethod.PUT, "/api/buses/**").hasRole("ADMIN")
                .requestMatchers(HttpMethod.DELETE, "/api/buses/**").hasRole("ADMIN")
                .requestMatchers(HttpMethod.POST, "/api/routes/**").hasRole("ADMIN")
                .requestMatchers(HttpMethod.PUT, "/api/routes/**").hasRole("ADMIN")
                .requestMatchers(HttpMethod.DELETE, "/api/routes/**").hasRole("ADMIN")

                // Everything else requires authentication
                .anyRequest().authenticated()
            )

            // Use our custom DaoAuthenticationProvider
            .authenticationProvider(authenticationProvider())

            // Add our JWT filter BEFORE Spring's default username/password filter.
            // This means: check for JWT first, before anything else.
            .addFilterBefore(jwtAuthenticationFilter,
                             UsernamePasswordAuthenticationFilter.class);

        return http.build();
    }
}
