package com.university.bustracker.model;

import jakarta.persistence.*;
import lombok.*;
import org.hibernate.annotations.CreationTimestamp;

import java.time.LocalDateTime;

/**
 * Notification.java — JPA Entity
 * ================================
 * Maps to the "notifications" table.
 * Admins can broadcast messages to students or drivers.
 */
@Entity
@Table(name = "notifications")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class Notification {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false, length = 200)
    private String title;

    @Column(nullable = false, columnDefinition = "TEXT")
    private String message;

    /**
     * Target audience. Values:
     * - "ROLE_STUDENT" = visible to students only
     * - "ROLE_DRIVER"  = visible to drivers only
     * - NULL           = visible to all roles
     */
    @Column(name = "recipient_role", length = 30)
    private String recipientRole;

    @Column(name = "is_read", nullable = false)
    @Builder.Default
    private Boolean isRead = false;

    @CreationTimestamp
    @Column(name = "created_at", nullable = false, updatable = false)
    private LocalDateTime createdAt;
}
