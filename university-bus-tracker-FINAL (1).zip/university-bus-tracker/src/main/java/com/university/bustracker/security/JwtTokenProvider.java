package com.university.bustracker.security;

import io.jsonwebtoken.*;
import io.jsonwebtoken.security.Keys;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Component;

import javax.crypto.SecretKey;
import java.util.Date;

/**
 * JwtTokenProvider.java
 * ======================
 * Handles all JWT (JSON Web Token) operations:
 * 1. Generating tokens after login
 * 2. Extracting username from tokens
 * 3. Validating tokens on each request
 *
 * HOW JWT WORKS:
 * A JWT is a Base64-encoded string with 3 parts separated by dots:
 * header.payload.signature
 *
 * Header:    { "alg": "HS256", "typ": "JWT" }
 * Payload:   { "sub": "ali@student.edu", "exp": 1234567890, "role": "ROLE_STUDENT" }
 * Signature: HMACSHA256(header + payload, secret_key)
 *
 * The signature means: "Anthropic signed this. If the payload was tampered
 * with, the signature would not match, and the token would be rejected."
 *
 * @Component: Spring creates one instance of this class and manages it.
 * @Value: Injects values from application.properties.
 */
@Component
public class JwtTokenProvider {

    private static final Logger logger = LoggerFactory.getLogger(JwtTokenProvider.class);

    /** Secret key string from application.properties */
    @Value("${app.jwt.secret}")
    private String jwtSecret;

    /** Token validity in milliseconds (e.g. 86400000 = 24 hours) */
    @Value("${app.jwt.expiration}")
    private long jwtExpirationMs;

    /**
     * Converts the raw secret string into a cryptographic key.
     * Called internally before signing or verifying tokens.
     * Uses HMAC-SHA256 algorithm.
     */
    private SecretKey getSigningKey() {
        // Convert the plain secret string to bytes directly.
        // Keys.hmacShaKeyFor() requires at least 256 bits (32 bytes) for HS256.
        byte[] keyBytes = jwtSecret.getBytes(java.nio.charset.StandardCharsets.UTF_8);
        return Keys.hmacShaKeyFor(keyBytes);
    }

    /**
     * Generates a new JWT token after successful authentication.
     *
     * @param authentication Spring Security object with the logged-in user's details
     * @return JWT token string
     *
     * The token contains:
     * - Subject (sub): the user's email address
     * - Issued At (iat): when the token was created
     * - Expiration (exp): when the token expires
     */
    public String generateToken(Authentication authentication) {
        UserDetails userDetails = (UserDetails) authentication.getPrincipal();
        Date now = new Date();
        Date expiryDate = new Date(now.getTime() + jwtExpirationMs);

        return Jwts.builder()
                .subject(userDetails.getUsername())     // email as subject
                .issuedAt(now)
                .expiration(expiryDate)
                .signWith(getSigningKey())
                .compact();  // builds and signs the token string
    }

    /**
     * Convenience method: generate token directly from email + role.
     * Used when we need a token without a Spring Authentication object.
     */
    public String generateTokenFromEmail(String email) {
        Date now = new Date();
        Date expiryDate = new Date(now.getTime() + jwtExpirationMs);

        return Jwts.builder()
                .subject(email)
                .issuedAt(now)
                .expiration(expiryDate)
                .signWith(getSigningKey())
                .compact();
    }

    /**
     * Extracts the email (subject) from a JWT token.
     * Used in the filter to identify who is making the request.
     */
    public String getEmailFromToken(String token) {
        return Jwts.parser()
                .verifyWith(getSigningKey())
                .build()
                .parseSignedClaims(token)
                .getPayload()
                .getSubject();
    }

    /**
     * Validates a JWT token.
     * Returns true if the token is:
     * - Properly signed (not tampered with)
     * - Not expired
     * - Not malformed
     *
     * @param token the JWT string to validate
     * @return true if valid, false if not
     */
    public boolean validateToken(String token) {
        try {
            Jwts.parser()
                .verifyWith(getSigningKey())
                .build()
                .parseSignedClaims(token);
            return true;  // No exception = valid token

        } catch (MalformedJwtException e) {
            logger.error("Invalid JWT token: {}", e.getMessage());
        } catch (ExpiredJwtException e) {
            logger.error("JWT token is expired: {}", e.getMessage());
        } catch (UnsupportedJwtException e) {
            logger.error("JWT token is unsupported: {}", e.getMessage());
        } catch (IllegalArgumentException e) {
            logger.error("JWT claims string is empty: {}", e.getMessage());
        }
        return false;
    }

    /** Returns expiration time in milliseconds */
    public long getJwtExpirationMs() {
        return jwtExpirationMs;
    }
}
