package com.university.bustracker.service;

import com.university.bustracker.dto.AdminDTO;
import com.university.bustracker.dto.DriverDTO;
import com.university.bustracker.model.Admin;
import com.university.bustracker.model.Bus;
import com.university.bustracker.model.Driver;
import com.university.bustracker.model.Trip;
import com.university.bustracker.repository.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * AdminService.java
 * Admin-specific operations: dashboard stats, driver management.
 *
 * BUG FIX #3: Added createAdmin() method so new admin accounts
 * can be created via the API with properly BCrypt-hashed passwords,
 * instead of relying only on raw SQL seed data.
 */
@Service
@Transactional
public class AdminService {

    @Autowired
    private DriverRepository driverRepository;

    @Autowired
    private StudentRepository studentRepository;

    @Autowired
    private BusRepository busRepository;

    @Autowired
    private RouteRepository routeRepository;

    @Autowired
    private TripRepository tripRepository;

    @Autowired
    private AdminRepository adminRepository;

    @Autowired
    private PasswordEncoder passwordEncoder;

    // ── Dashboard ──────────────────────────────────────────────────

    @Transactional(readOnly = true)
    public Map<String, Object> getDashboardStats() {
        Map<String, Object> stats = new HashMap<>();
        stats.put("totalStudents",     studentRepository.count());
        stats.put("activeStudents",    studentRepository.countByIsActiveTrue());
        stats.put("totalDrivers",      driverRepository.count());
        stats.put("activeDrivers",     driverRepository.countByIsActiveTrue());
        stats.put("totalBuses",        busRepository.count());
        stats.put("activeBuses",       busRepository.countByStatus(Bus.BusStatus.ACTIVE));
        stats.put("inactiveBuses",     busRepository.countByStatus(Bus.BusStatus.INACTIVE));
        stats.put("maintenanceBuses",  busRepository.countByStatus(Bus.BusStatus.MAINTENANCE));
        stats.put("totalRoutes",       routeRepository.count());
        stats.put("activeRoutes",      routeRepository.countByIsActiveTrue());
        stats.put("completedTrips",    tripRepository.countByStatus(Trip.TripStatus.COMPLETED));
        stats.put("activeTrips",
                tripRepository.countByStatus(Trip.TripStatus.STARTED) +
                tripRepository.countByStatus(Trip.TripStatus.IN_PROGRESS));
        return stats;
    }

    // ── Driver Management ──────────────────────────────────────────

    @Transactional(readOnly = true)
    public List<DriverDTO> getAllDrivers() {
        return driverRepository.findAll().stream()
                .map(this::convertDriverToDTO)
                .collect(Collectors.toList());
    }

    @Transactional(readOnly = true)
    public DriverDTO getDriverById(Long id) {
        Driver driver = driverRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Driver not found with id: " + id));
        return convertDriverToDTO(driver);
    }

    public DriverDTO createDriver(DriverDTO dto) {
        if (driverRepository.existsByEmail(dto.getEmail())) {
            throw new RuntimeException("Email already registered: " + dto.getEmail());
        }
        Driver driver = Driver.builder()
                .name(dto.getName())
                .email(dto.getEmail())
                .password(passwordEncoder.encode(dto.getPassword()))
                .phone(dto.getPhone())
                .licenseNumber(dto.getLicenseNumber())
                .isActive(true)
                .build();
        if (dto.getBusId() != null) {
            busRepository.findById(dto.getBusId()).ifPresent(driver::setBus);
        }
        return convertDriverToDTO(driverRepository.save(driver));
    }

    public DriverDTO updateDriver(Long id, DriverDTO dto) {
        Driver driver = driverRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Driver not found with id: " + id));
        if (dto.getName() != null)          driver.setName(dto.getName());
        if (dto.getPhone() != null)         driver.setPhone(dto.getPhone());
        if (dto.getLicenseNumber() != null) driver.setLicenseNumber(dto.getLicenseNumber());
        if (dto.getIsActive() != null)      driver.setIsActive(dto.getIsActive());
        if (dto.getBusId() != null) {
            busRepository.findById(dto.getBusId()).ifPresent(driver::setBus);
        }
        return convertDriverToDTO(driverRepository.save(driver));
    }

    public void deleteDriver(Long id) {
        if (!driverRepository.existsById(id)) {
            throw new RuntimeException("Driver not found with id: " + id);
        }
        driverRepository.deleteById(id);
    }

    // ── Admin Management (BUG FIX #3) ─────────────────────────────

    /**
     * Creates a new Admin account with a properly BCrypt-hashed password.
     * Only an existing Admin can call this (secured in AdminController).
     *
     * This is the correct alternative to inserting raw SQL with a manually
     * crafted hash, which was the root cause of the broken admin logins.
     */
    public AdminDTO createAdmin(AdminDTO dto) {
        if (adminRepository.existsByEmail(dto.getEmail())) {
            throw new RuntimeException("Email already registered: " + dto.getEmail());
        }
        Admin admin = Admin.builder()
                .name(dto.getName())
                .email(dto.getEmail())
                .password(passwordEncoder.encode(dto.getPassword()))  // Correctly hashed
                .phone(dto.getPhone())
                .role("ROLE_ADMIN")
                .isActive(true)
                .build();
        Admin saved = adminRepository.save(admin);
        return convertAdminToDTO(saved);
    }

    // ── Converters ─────────────────────────────────────────────────

    private DriverDTO convertDriverToDTO(Driver driver) {
        DriverDTO dto = DriverDTO.builder()
                .id(driver.getId())
                .name(driver.getName())
                .email(driver.getEmail())
                .phone(driver.getPhone())
                .licenseNumber(driver.getLicenseNumber())
                .isActive(driver.getIsActive())
                .createdAt(driver.getCreatedAt())
                .build();
        if (driver.getBus() != null) {
            dto.setBusId(driver.getBus().getId());
            dto.setBusNumber(driver.getBus().getBusNumber());
            if (driver.getBus().getRoute() != null) {
                dto.setRouteName(driver.getBus().getRoute().getRouteName());
            }
        }
        return dto;
    }

    private AdminDTO convertAdminToDTO(Admin admin) {
        return AdminDTO.builder()
                .id(admin.getId())
                .name(admin.getName())
                .email(admin.getEmail())
                .phone(admin.getPhone())
                .isActive(admin.getIsActive())
                .createdAt(admin.getCreatedAt())
                .build();
    }
}
