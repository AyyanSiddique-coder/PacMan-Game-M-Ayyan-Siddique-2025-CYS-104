package com.university.bustracker.repository;

import com.university.bustracker.model.Student;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

/**
 * StudentRepository.java
 * =======================
 * Spring Data JPA repository for the Student entity.
 *
 * By extending JpaRepository<Student, Long>:
 * - Student = the entity type
 * - Long    = the primary key type
 *
 * Spring Data automatically provides these methods FOR FREE:
 * - save(student)           → INSERT or UPDATE
 * - findById(id)            → SELECT WHERE id = ?
 * - findAll()               → SELECT * FROM students
 * - deleteById(id)          → DELETE WHERE id = ?
 * - count()                 → SELECT COUNT(*)
 * - existsById(id)          → SELECT EXISTS(...)
 *
 * Custom methods below follow Spring Data naming conventions.
 * Spring Data reads the method name and generates the SQL automatically.
 */
@Repository
public interface StudentRepository extends JpaRepository<Student, Long> {

    /**
     * findByEmail → SELECT * FROM students WHERE email = ?
     * Returns Optional<Student> so caller must handle "not found" case.
     * Used during login to find the student by email.
     */
    Optional<Student> findByEmail(String email);

    /**
     * existsByEmail → SELECT EXISTS(SELECT 1 FROM students WHERE email = ?)
     * Used during registration to check if email is already taken.
     */
    boolean existsByEmail(String email);

    /**
     * existsByStudentId → checks if university ID is already registered.
     */
    boolean existsByStudentId(String studentId);

    /**
     * Count active students for admin dashboard statistics.
     */
    long countByIsActiveTrue();
}
