package com.university.bustracker.controller;

import com.university.bustracker.dto.ApiResponse;
import com.university.bustracker.dto.LocationUpdateRequest;
import com.university.bustracker.model.BusLocation;
import com.university.bustracker.service.LocationService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/api/location")
@CrossOrigin(origins = "*")
public class LocationController {

    @Autowired
    private LocationService locationService;

    /**
     * POST /api/location/update
     * Called by driver browser every few seconds with new GPS coordinates.
     * Requires ROLE_DRIVER (enforced in SecurityConfig).
     * Authentication object is automatically injected by Spring Security.
     */
    @PostMapping("/update")
    public ResponseEntity<ApiResponse<Void>> updateLocation(
            @Valid @RequestBody LocationUpdateRequest request,
            Authentication authentication) {
        try {
            // authentication.getName() returns the email from the JWT token
            locationService.updateLocation(authentication.getName(), request);
            return ResponseEntity.ok(ApiResponse.success("Location updated"));
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(ApiResponse.error(e.getMessage()));
        }
    }

    /**
     * GET /api/location/bus/{busId}
     * Get the latest GPS location for a specific bus.
     * Public endpoint - students can call this.
     */
    @GetMapping("/bus/{busId}")
    public ResponseEntity<ApiResponse<Map<String, Object>>> getLatestLocation(@PathVariable Long busId) {
        Optional<BusLocation> locationOpt = locationService.getLatestLocation(busId);
        if (locationOpt.isPresent()) {
            BusLocation loc = locationOpt.get();
            Map<String, Object> data = buildLocationMap(loc);
            return ResponseEntity.ok(ApiResponse.success("Location found", data));
        }
        return ResponseEntity.ok(ApiResponse.error("No location data available for this bus"));
    }

    /**
     * GET /api/location/all
     * Get latest location of ALL buses - used by student map.
     */
    @GetMapping("/all")
    public ResponseEntity<ApiResponse<List<Map<String, Object>>>> getAllLatestLocations() {
        List<Map<String, Object>> locations = locationService.getAllLatestLocations()
                .stream()
                .map(this::buildLocationMap)
                .collect(Collectors.toList());
        return ResponseEntity.ok(ApiResponse.success("All locations fetched", locations));
    }

    /**
     * GET /api/location/bus/{busId}/trail
     * Get recent location trail for drawing bus path on map.
     */
    @GetMapping("/bus/{busId}/trail")
    public ResponseEntity<ApiResponse<List<Map<String, Object>>>> getLocationTrail(
            @PathVariable Long busId,
            @RequestParam(defaultValue = "20") int limit) {
        List<Map<String, Object>> trail = locationService.getRecentLocations(busId, limit)
                .stream()
                .map(this::buildLocationMap)
                .collect(Collectors.toList());
        return ResponseEntity.ok(ApiResponse.success("Trail fetched", trail));
    }

    /** Helper: convert BusLocation entity to a simple Map for JSON response */
    private Map<String, Object> buildLocationMap(BusLocation loc) {
        Map<String, Object> map = new HashMap<>();
        map.put("locationId", loc.getId());
        map.put("busId", loc.getBus().getId());
        map.put("busNumber", loc.getBus().getBusNumber());
        map.put("latitude", loc.getLatitude());
        map.put("longitude", loc.getLongitude());
        map.put("speed", loc.getSpeed());
        map.put("heading", loc.getHeading());
        map.put("accuracy", loc.getAccuracy());
        map.put("recordedAt", loc.getRecordedAt());
        if (loc.getBus().getRoute() != null) {
            map.put("routeName", loc.getBus().getRoute().getRouteName());
            map.put("routeCode", loc.getBus().getRoute().getRouteCode());
        }
        return map;
    }
}
