package com.university.bustracker.repository;

import com.university.bustracker.model.Notification;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

/** NotificationRepository — DB access for Notification entities. */
@Repository
public interface NotificationRepository extends JpaRepository<Notification, Long> {

    /**
     * Get notifications for a specific role OR global (null role).
     * Students see ROLE_STUDENT + global notifications.
     */
    @Query("SELECT n FROM Notification n WHERE n.recipientRole = :role OR n.recipientRole IS NULL ORDER BY n.createdAt DESC")
    List<Notification> findByRoleOrGlobal(@Param("role") String role);

    List<Notification> findAllByOrderByCreatedAtDesc();
}
