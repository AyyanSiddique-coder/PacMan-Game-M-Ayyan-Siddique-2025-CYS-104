package com.university.bustracker.repository;

import com.university.bustracker.model.BusLocation;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

/**
 * BusLocationRepository — DB access for GPS location data.
 *
 * The most critical query here is getLatestLocationForBus().
 * Students call this repeatedly to get the bus's current position.
 */
@Repository
public interface BusLocationRepository extends JpaRepository<BusLocation, Long> {

    /**
     * Get the single most recent GPS coordinate for a given bus.
     *
     * JPQL query explanation:
     * - "FROM BusLocation bl" = query the BusLocation entity
     * - "WHERE bl.bus.id = :busId" = filter by bus
     * - "ORDER BY bl.recordedAt DESC" = newest first
     * - Limit 1 via Spring Data's findFirst/findTop1 convention
     *
     * This is what students see on the map as the bus's current position.
     */
    @Query("SELECT bl FROM BusLocation bl WHERE bl.bus.id = :busId ORDER BY bl.recordedAt DESC LIMIT 1")
    Optional<BusLocation> findLatestByBusId(@Param("busId") Long busId);

    /**
     * Get the latest location for ALL buses.
     * Used by the student map to show all buses at once.
     *
     * This uses a subquery to find the max recorded_at per bus.
     * The DISTINCT ON approach used here is JPQL-compatible.
     */
    @Query(value = """
        SELECT bl.* FROM bus_locations bl
        INNER JOIN (
            SELECT bus_id, MAX(recorded_at) as max_time
            FROM bus_locations
            GROUP BY bus_id
        ) latest ON bl.bus_id = latest.bus_id AND bl.recorded_at = latest.max_time
        """, nativeQuery = true)
    List<BusLocation> findLatestLocationForAllBuses();

    /**
     * Get location history for a specific trip.
     * Used to draw the path the bus has taken on the map.
     */
    List<BusLocation> findByTripIdOrderByRecordedAtAsc(Long tripId);

    /**
     * Get recent locations for a bus (last N records).
     * Used to draw a "trail" showing where the bus has been.
     */
    @Query("SELECT bl FROM BusLocation bl WHERE bl.bus.id = :busId ORDER BY bl.recordedAt DESC LIMIT :limit")
    List<BusLocation> findRecentByBusId(@Param("busId") Long busId, @Param("limit") int limit);
}
