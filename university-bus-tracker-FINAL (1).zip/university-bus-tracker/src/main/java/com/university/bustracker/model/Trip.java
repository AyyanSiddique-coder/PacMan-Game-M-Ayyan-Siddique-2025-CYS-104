package com.university.bustracker.model;

import jakarta.persistence.*;
import lombok.*;
import org.hibernate.annotations.CreationTimestamp;

import java.time.LocalDateTime;

/**
 * Trip.java — JPA Entity
 * =======================
 * Maps to the "trips" table.
 * A Trip is created when a driver clicks "Start Trip".
 * It is closed when the driver clicks "End Trip".
 *
 * The Trip links a Driver + Bus + Route together for one journey.
 * It helps track:
 * - When a bus started and ended its run
 * - Which locations belong to which trip (via BusLocation.trip)
 *
 * TripStatus lifecycle:
 * STARTED → IN_PROGRESS → COMPLETED
 *         ↘ CANCELLED
 */
@Entity
@Table(name = "trips")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class Trip {

    /** Trip status. */
    public enum TripStatus {
        STARTED,       // Driver just clicked Start
        IN_PROGRESS,   // Bus is actively moving
        COMPLETED,     // Driver ended the trip normally
        CANCELLED      // Trip was cancelled mid-way
    }

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    /** The driver who started this trip */
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "driver_id", nullable = false)
    @ToString.Exclude
    private Driver driver;

    /** The bus used for this trip */
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "bus_id", nullable = false)
    @ToString.Exclude
    private Bus bus;

    /** The route being driven */
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "route_id", nullable = false)
    @ToString.Exclude
    private Route route;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false, length = 20)
    @Builder.Default
    private TripStatus status = TripStatus.STARTED;

    @Column(name = "start_time", nullable = false)
    @Builder.Default
    private LocalDateTime startTime = LocalDateTime.now();

    /** Set when the driver ends the trip */
    @Column(name = "end_time")
    private LocalDateTime endTime;

    @Column(columnDefinition = "TEXT")
    private String notes;

    @CreationTimestamp
    @Column(name = "created_at", nullable = false, updatable = false)
    private LocalDateTime createdAt;
}
