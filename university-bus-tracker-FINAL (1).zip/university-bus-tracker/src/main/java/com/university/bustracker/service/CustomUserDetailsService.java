package com.university.bustracker.service;

import com.university.bustracker.model.Admin;
import com.university.bustracker.model.Driver;
import com.university.bustracker.model.Student;
import com.university.bustracker.repository.AdminRepository;
import com.university.bustracker.repository.DriverRepository;
import com.university.bustracker.repository.StudentRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import java.util.Collections;

/**
 * CustomUserDetailsService.java
 * ==============================
 * Spring Security requires a UserDetailsService that loads user data
 * by username (email) during authentication.
 *
 * We have 3 separate tables (students, drivers, admins).
 * We search all three in order: student → driver → admin.
 *
 * BUG FIX #2:
 * - Driver block was missing .accountExpired(false) and .credentialsExpired(false).
 *   Without these, Spring Security's User.builder() may throw an
 *   InternalAuthenticationServiceException on some versions.
 * - Admin block was missing ALL account-status flags, and Admin had no isActive field.
 *   Both are now corrected.
 */
@Service
public class CustomUserDetailsService implements UserDetailsService {

    @Autowired
    private StudentRepository studentRepository;

    @Autowired
    private DriverRepository driverRepository;

    @Autowired
    private AdminRepository adminRepository;

    @Override
    public UserDetails loadUserByUsername(String email) throws UsernameNotFoundException {

        // ── 1. Check students table ──────────────────────────────────────
        var student = studentRepository.findByEmail(email);
        if (student.isPresent()) {
            Student s = student.get();
            return User.builder()
                    .username(s.getEmail())
                    .password(s.getPassword())
                    .authorities(Collections.singleton(
                        new SimpleGrantedAuthority(s.getRole())
                    ))
                    .accountExpired(false)
                    .accountLocked(!s.getIsActive())
                    .credentialsExpired(false)
                    .disabled(!s.getIsActive())
                    .build();
        }

        // ── 2. Check drivers table ───────────────────────────────────────
        var driver = driverRepository.findByEmail(email);
        if (driver.isPresent()) {
            Driver d = driver.get();
            return User.builder()
                    .username(d.getEmail())
                    .password(d.getPassword())
                    .authorities(Collections.singleton(
                        new SimpleGrantedAuthority(d.getRole())
                    ))
                    .accountExpired(false)                   // BUG FIX #2: was missing
                    .accountLocked(!d.getIsActive())
                    .credentialsExpired(false)               // BUG FIX #2: was missing
                    .disabled(!d.getIsActive())
                    .build();
        }

        // ── 3. Check admins table ────────────────────────────────────────
        var admin = adminRepository.findByEmail(email);
        if (admin.isPresent()) {
            Admin a = admin.get();
            return User.builder()
                    .username(a.getEmail())
                    .password(a.getPassword())
                    .authorities(Collections.singleton(
                        new SimpleGrantedAuthority(a.getRole())
                    ))
                    .accountExpired(false)                   // BUG FIX #2: was missing
                    .accountLocked(!a.getIsActive())         // BUG FIX #2: was missing (needed isActive on Admin)
                    .credentialsExpired(false)               // BUG FIX #2: was missing
                    .disabled(!a.getIsActive())              // BUG FIX #2: was missing
                    .build();
        }

        throw new UsernameNotFoundException("User not found with email: " + email);
    }
}
