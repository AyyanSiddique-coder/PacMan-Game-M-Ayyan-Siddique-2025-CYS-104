package com.university.bustracker.controller;

import com.university.bustracker.dto.ApiResponse;
import com.university.bustracker.dto.BusDTO;
import com.university.bustracker.service.BusService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/buses")
@CrossOrigin(origins = "*")
public class BusController {

    @Autowired
    private BusService busService;

    @GetMapping
    public ResponseEntity<ApiResponse<List<BusDTO>>> getAllBuses() {
        return ResponseEntity.ok(ApiResponse.success("Buses fetched", busService.getAllBuses()));
    }

    @GetMapping("/{id}")
    public ResponseEntity<ApiResponse<BusDTO>> getBusById(@PathVariable Long id) {
        try {
            return ResponseEntity.ok(ApiResponse.success("Bus fetched", busService.getBusById(id)));
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(ApiResponse.error(e.getMessage()));
        }
    }

    @GetMapping("/active")
    public ResponseEntity<ApiResponse<List<BusDTO>>> getActiveBuses() {
        return ResponseEntity.ok(ApiResponse.success("Active buses fetched", busService.getActiveBuses()));
    }

    @PostMapping
    public ResponseEntity<ApiResponse<BusDTO>> createBus(@Valid @RequestBody BusDTO dto) {
        try {
            return ResponseEntity.status(HttpStatus.CREATED)
                    .body(ApiResponse.success("Bus created successfully", busService.createBus(dto)));
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(ApiResponse.error(e.getMessage()));
        }
    }

    @PutMapping("/{id}")
    public ResponseEntity<ApiResponse<BusDTO>> updateBus(@PathVariable Long id, @RequestBody BusDTO dto) {
        try {
            return ResponseEntity.ok(ApiResponse.success("Bus updated", busService.updateBus(id, dto)));
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(ApiResponse.error(e.getMessage()));
        }
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<ApiResponse<Void>> deleteBus(@PathVariable Long id) {
        try {
            busService.deleteBus(id);
            return ResponseEntity.ok(ApiResponse.success("Bus deleted"));
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(ApiResponse.error(e.getMessage()));
        }
    }

    @PostMapping("/{busId}/assign-driver/{driverId}")
    public ResponseEntity<ApiResponse<Void>> assignDriver(@PathVariable Long busId, @PathVariable Long driverId) {
        try {
            busService.assignDriverToBus(busId, driverId);
            return ResponseEntity.ok(ApiResponse.success("Driver assigned to bus"));
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(ApiResponse.error(e.getMessage()));
        }
    }
}
