package com.university.bustracker.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * LoginResponse.java — DTO
 * =========================
 * Sent BACK to the browser after a successful login.
 * Contains the JWT token and basic user info.
 *
 * The browser stores the JWT in localStorage and sends it
 * in the Authorization header for all subsequent requests:
 * Authorization: Bearer eyJhbGci...
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class LoginResponse {

    /** JWT token string. Browser stores this. */
    private String token;

    /** Token type is always "Bearer" */
    private String tokenType = "Bearer";

    private Long userId;
    private String name;
    private String email;
    private String role;

    /** Seconds until the token expires (e.g., 86400 = 24 hours) */
    private long expiresIn;
}
