package com.university.bustracker.dto;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

/**
 * DriverDTO.java
 * Used by admin to create/update drivers, and return driver info.
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class DriverDTO {

    private Long id;

    @NotBlank(message = "Name is required")
    private String name;

    @Email
    @NotBlank
    private String email;

    /** Only used when creating a new driver. Not returned in responses. */
    private String password;

    private String phone;
    private String licenseNumber;
    private Boolean isActive;
    private Long busId;
    private String busNumber;
    private String routeName;
    private LocalDateTime createdAt;
}
