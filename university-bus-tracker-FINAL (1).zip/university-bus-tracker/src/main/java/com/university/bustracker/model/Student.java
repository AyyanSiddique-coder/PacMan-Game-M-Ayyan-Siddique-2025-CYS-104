package com.university.bustracker.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import lombok.*;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import java.time.LocalDateTime;

/**
 * Student.java — JPA Entity
 * ==========================
 * Represents the "students" table in MySQL.
 *
 * @Entity   : Tells JPA this class maps to a database table.
 * @Table    : Specifies the exact table name.
 * @Id      : Marks the primary key field.
 * @GeneratedValue : Auto-increments the ID (MySQL AUTO_INCREMENT).
 *
 * Lombok annotations:
 * @Data     : Generates getters, setters, equals, hashCode, toString
 * @Builder  : Enables the Builder pattern (Student.builder().name("Ali").build())
 * @NoArgsConstructor / @AllArgsConstructor: Generates constructors
 */
@Entity
@Table(name = "students")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class Student {

    /**
     * Primary key. AUTO_INCREMENT in MySQL.
     * IDENTITY strategy tells JPA to let MySQL handle ID generation.
     */
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    /**
     * Student's full name. @Column(nullable = false) maps to
     * VARCHAR NOT NULL in MySQL.
     */
    @NotBlank(message = "Name is required")
    @Column(nullable = false, length = 100)
    private String name;

    /**
     * Email must be unique (used as login username).
     * @Email validates the format on the Java side.
     */
    @Email(message = "Invalid email format")
    @NotBlank(message = "Email is required")
    @Column(nullable = false, unique = true, length = 150)
    private String email;

    /**
     * BCrypt-hashed password. NEVER store plain text passwords.
     * @Column(length = 255) because BCrypt hashes are 60 chars,
     * but we use 255 for safety.
     */
    @NotBlank(message = "Password is required")
    @Column(nullable = false, length = 255)
    private String password;

    /** University-issued student ID like "CS-2021-001" */
    @Column(name = "student_id", unique = true, length = 50)
    private String studentId;

    @Column(length = 20)
    private String phone;

    @Column(length = 100)
    private String department;

    /**
     * Role is always ROLE_STUDENT for this entity.
     * Spring Security uses this for authorization.
     */
    @Column(nullable = false, length = 30)
    @Builder.Default
    private String role = "ROLE_STUDENT";

    /**
     * Soft delete flag. If false, student cannot log in.
     */
    @Column(name = "is_active", nullable = false)
    @Builder.Default
    private Boolean isActive = true;

    /**
     * @CreationTimestamp: Hibernate automatically sets this
     * to the current timestamp when the record is first saved.
     * updatable = false ensures it never changes after creation.
     */
    @CreationTimestamp
    @Column(name = "created_at", nullable = false, updatable = false)
    private LocalDateTime createdAt;

    /**
     * @UpdateTimestamp: Hibernate updates this every time
     * the entity is saved/updated.
     */
    @UpdateTimestamp
    @Column(name = "updated_at", nullable = false)
    private LocalDateTime updatedAt;
}
