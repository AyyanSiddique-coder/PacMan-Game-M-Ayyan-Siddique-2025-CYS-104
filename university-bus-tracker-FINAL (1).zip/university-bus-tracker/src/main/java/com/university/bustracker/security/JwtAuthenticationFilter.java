package com.university.bustracker.security;

import com.university.bustracker.service.CustomUserDetailsService;
import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.web.authentication.WebAuthenticationDetailsSource;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;
import org.springframework.web.filter.OncePerRequestFilter;

import java.io.IOException;

/**
 * JwtAuthenticationFilter.java
 * =============================
 * This filter runs for EVERY HTTP request before the controller.
 * It checks if the request has a valid JWT token and, if so,
 * sets up the Spring Security authentication context.
 *
 * Flow:
 * 1. Browser sends: GET /api/buses   Authorization: Bearer eyJhbGci...
 * 2. This filter intercepts the request
 * 3. Extracts the token from the Authorization header
 * 4. Validates the token with JwtTokenProvider
 * 5. Loads user details from the database
 * 6. Sets up the Security Context so Spring knows who the user is
 * 7. The request proceeds to the controller
 *
 * OncePerRequestFilter: Ensures this filter runs exactly once per request.
 */
@Component
public class JwtAuthenticationFilter extends OncePerRequestFilter {

    private static final Logger logger = LoggerFactory.getLogger(JwtAuthenticationFilter.class);

    @Autowired
    private JwtTokenProvider tokenProvider;

    @Autowired
    private CustomUserDetailsService userDetailsService;

    /**
     * Core filter logic. Called for every request.
     *
     * @param request     The incoming HTTP request
     * @param response    The outgoing HTTP response
     * @param filterChain The chain of remaining filters
     */
    @Override
    protected void doFilterInternal(HttpServletRequest request,
                                    HttpServletResponse response,
                                    FilterChain filterChain)
            throws ServletException, IOException {

        try {
            // Step 1: Extract JWT from "Authorization: Bearer <token>" header
            String jwt = extractJwtFromRequest(request);

            // Step 2: Validate the token
            if (StringUtils.hasText(jwt) && tokenProvider.validateToken(jwt)) {

                // Step 3: Get the email (username) from the token
                String email = tokenProvider.getEmailFromToken(jwt);

                // Step 4: Load user details from the database using the email
                // This checks that the user still exists and is active
                UserDetails userDetails = userDetailsService.loadUserByUsername(email);

                // Step 5: Create an authentication object
                // This tells Spring Security who the user is and what roles they have
                UsernamePasswordAuthenticationToken authentication =
                    new UsernamePasswordAuthenticationToken(
                        userDetails,        // principal (the user)
                        null,               // credentials (null = already authenticated)
                        userDetails.getAuthorities()  // roles (ROLE_STUDENT, etc.)
                    );

                // Attach request details (IP address, session info) to authentication
                authentication.setDetails(
                    new WebAuthenticationDetailsSource().buildDetails(request)
                );

                // Step 6: Store authentication in the Security Context
                // This makes it available throughout the request lifecycle
                SecurityContextHolder.getContext().setAuthentication(authentication);

                logger.debug("User '{}' authenticated via JWT", email);
            }
        } catch (Exception ex) {
            // Log but don't throw — let Spring Security handle unauthorized access
            logger.error("Could not set user authentication in security context", ex);
        }

        // Step 7: Continue to the next filter / controller
        filterChain.doFilter(request, response);
    }

    /**
     * Extracts the JWT token from the Authorization header.
     *
     * Expected header format: "Authorization: Bearer eyJhbGci..."
     *
     * @param request the HTTP request
     * @return the raw JWT token string, or null if not found
     */
    private String extractJwtFromRequest(HttpServletRequest request) {
        String bearerToken = request.getHeader("Authorization");

        // Check that header starts with "Bearer "
        if (StringUtils.hasText(bearerToken) && bearerToken.startsWith("Bearer ")) {
            return bearerToken.substring(7);  // Remove "Bearer " prefix (7 chars)
        }

        return null;
    }
}
