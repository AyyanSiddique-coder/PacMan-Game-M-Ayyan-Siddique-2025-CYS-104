package com.university.bustracker.controller;

import com.university.bustracker.dto.ApiResponse;
import com.university.bustracker.dto.RouteDTO;
import com.university.bustracker.service.RouteService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/routes")
@CrossOrigin(origins = "*")
public class RouteController {

    @Autowired
    private RouteService routeService;

    @GetMapping
    public ResponseEntity<ApiResponse<List<RouteDTO>>> getAllRoutes() {
        return ResponseEntity.ok(ApiResponse.success("Routes fetched", routeService.getAllRoutes()));
    }

    @GetMapping("/active")
    public ResponseEntity<ApiResponse<List<RouteDTO>>> getActiveRoutes() {
        return ResponseEntity.ok(ApiResponse.success("Active routes fetched", routeService.getActiveRoutes()));
    }

    @GetMapping("/{id}")
    public ResponseEntity<ApiResponse<RouteDTO>> getRouteById(@PathVariable Long id) {
        try {
            return ResponseEntity.ok(ApiResponse.success("Route fetched", routeService.getRouteById(id)));
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(ApiResponse.error(e.getMessage()));
        }
    }

    @PostMapping
    public ResponseEntity<ApiResponse<RouteDTO>> createRoute(@RequestBody RouteDTO dto) {
        try {
            return ResponseEntity.status(HttpStatus.CREATED)
                    .body(ApiResponse.success("Route created", routeService.createRoute(dto)));
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(ApiResponse.error(e.getMessage()));
        }
    }

    @PutMapping("/{id}")
    public ResponseEntity<ApiResponse<RouteDTO>> updateRoute(@PathVariable Long id, @RequestBody RouteDTO dto) {
        try {
            return ResponseEntity.ok(ApiResponse.success("Route updated", routeService.updateRoute(id, dto)));
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(ApiResponse.error(e.getMessage()));
        }
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<ApiResponse<Void>> deleteRoute(@PathVariable Long id) {
        try {
            routeService.deleteRoute(id);
            return ResponseEntity.ok(ApiResponse.success("Route deleted"));
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(ApiResponse.error(e.getMessage()));
        }
    }
}
