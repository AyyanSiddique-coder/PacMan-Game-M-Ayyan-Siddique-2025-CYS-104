package com.university.bustracker.service;

import com.university.bustracker.dto.TripDTO;
import com.university.bustracker.model.Driver;
import com.university.bustracker.model.Trip;
import com.university.bustracker.repository.DriverRepository;
import com.university.bustracker.repository.TripRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

/**
 * TripService.java
 * Business logic for trip lifecycle management.
 * Start trip → track location → end trip.
 */
@Service
@Transactional
public class TripService {

    @Autowired
    private TripRepository tripRepository;

    @Autowired
    private DriverRepository driverRepository;

    /**
     * Driver starts a trip.
     * Validates that:
     * - Driver has an assigned bus
     * - Driver has no other active trip
     * - The bus has an assigned route
     *
     * @param driverEmail email from JWT token
     * @return TripDTO of the newly created trip
     */
    public TripDTO startTrip(String driverEmail) {
        Driver driver = driverRepository.findByEmail(driverEmail)
                .orElseThrow(() -> new RuntimeException("Driver not found"));

        // Check driver has a bus
        if (driver.getBus() == null) {
            throw new RuntimeException("You have no assigned bus. Contact admin.");
        }

        // Check driver doesn't already have an active trip
        List<Trip.TripStatus> activeStatuses = Arrays.asList(
            Trip.TripStatus.STARTED, Trip.TripStatus.IN_PROGRESS
        );
        tripRepository.findByDriverIdAndStatusIn(driver.getId(), activeStatuses)
                .ifPresent(t -> {
                    throw new RuntimeException("You already have an active trip (ID: " + t.getId() + ")");
                });

        // Check bus has a route
        if (driver.getBus().getRoute() == null) {
            throw new RuntimeException("Your bus has no assigned route. Contact admin.");
        }

        // Create and save the trip
        Trip trip = Trip.builder()
                .driver(driver)
                .bus(driver.getBus())
                .route(driver.getBus().getRoute())
                .status(Trip.TripStatus.STARTED)
                .startTime(LocalDateTime.now())
                .build();

        return convertToDTO(tripRepository.save(trip));
    }

    /**
     * Driver ends their active trip.
     *
     * @param driverEmail email from JWT
     * @param tripId      the trip to end
     * @return Updated TripDTO
     */
    public TripDTO endTrip(String driverEmail, Long tripId) {
        Trip trip = tripRepository.findById(tripId)
                .orElseThrow(() -> new RuntimeException("Trip not found: " + tripId));

        // Security check: the driver can only end THEIR OWN trip
        if (!trip.getDriver().getEmail().equals(driverEmail)) {
            throw new RuntimeException("You cannot end another driver's trip");
        }

        // Validate the trip is still active
        if (trip.getStatus() == Trip.TripStatus.COMPLETED ||
            trip.getStatus() == Trip.TripStatus.CANCELLED) {
            throw new RuntimeException("Trip is already " + trip.getStatus());
        }

        // Mark as completed
        trip.setStatus(Trip.TripStatus.COMPLETED);
        trip.setEndTime(LocalDateTime.now());

        return convertToDTO(tripRepository.save(trip));
    }

    /**
     * Get the driver's currently active trip (if any).
     */
    @Transactional(readOnly = true)
    public TripDTO getActiveTrip(String driverEmail) {
        Driver driver = driverRepository.findByEmail(driverEmail)
                .orElseThrow(() -> new RuntimeException("Driver not found"));

        List<Trip.TripStatus> activeStatuses = Arrays.asList(
            Trip.TripStatus.STARTED, Trip.TripStatus.IN_PROGRESS
        );

        return tripRepository.findByDriverIdAndStatusIn(driver.getId(), activeStatuses)
                .map(this::convertToDTO)
                .orElse(null);
    }

    /** Get trip history for a driver */
    @Transactional(readOnly = true)
    public List<TripDTO> getDriverTripHistory(String driverEmail) {
        Driver driver = driverRepository.findByEmail(driverEmail)
                .orElseThrow(() -> new RuntimeException("Driver not found"));

        return tripRepository.findByDriverIdOrderByStartTimeDesc(driver.getId())
                .stream()
                .map(this::convertToDTO)
                .collect(Collectors.toList());
    }

    /** Converts Trip entity → TripDTO */
    private TripDTO convertToDTO(Trip trip) {
        return TripDTO.builder()
                .id(trip.getId())
                .driverId(trip.getDriver().getId())
                .driverName(trip.getDriver().getName())
                .busId(trip.getBus().getId())
                .busNumber(trip.getBus().getBusNumber())
                .routeId(trip.getRoute().getId())
                .routeName(trip.getRoute().getRouteName())
                .status(trip.getStatus().name())
                .startTime(trip.getStartTime())
                .endTime(trip.getEndTime())
                .notes(trip.getNotes())
                .build();
    }
}
