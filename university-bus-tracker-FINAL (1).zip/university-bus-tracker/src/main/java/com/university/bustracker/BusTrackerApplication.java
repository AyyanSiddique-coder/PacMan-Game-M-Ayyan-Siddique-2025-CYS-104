package com.university.bustracker;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.scheduling.annotation.EnableScheduling;

/**
 * BusTrackerApplication.java
 * ==========================
 * This is the ENTRY POINT of the entire Spring Boot application.
 *
 * @SpringBootApplication is a shortcut annotation that combines:
 *   - @Configuration       : Marks this as a configuration source
 *   - @EnableAutoConfiguration : Lets Spring Boot auto-configure beans
 *   - @ComponentScan       : Scans the package for Spring components
 *
 * @EnableScheduling enables scheduled tasks (e.g., cleanup old locations)
 *
 * When you click "Run" in IntelliJ, execution starts here.
 */
@SpringBootApplication
@EnableScheduling
public class BusTrackerApplication {

    /**
     * main() is the JVM entry point.
     * SpringApplication.run() bootstraps the entire Spring context,
     * starts the embedded Tomcat server, and initializes all beans.
     */
    public static void main(String[] args) {
        SpringApplication.run(BusTrackerApplication.class, args);
        System.out.println("========================================");
        System.out.println("  University Bus Tracker is RUNNING!");
        System.out.println("  http://localhost:8080");
        System.out.println("========================================");
    }
}
