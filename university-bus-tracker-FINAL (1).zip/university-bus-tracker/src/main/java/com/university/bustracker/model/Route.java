package com.university.bustracker.model;

import jakarta.persistence.*;
import lombok.*;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

/**
 * Route.java — JPA Entity
 * ========================
 * Maps to the "routes" table.
 * A Route is a defined path from start to end with multiple stops.
 *
 * Key relationships:
 * - One Route has MANY RouteStops (one-to-many).
 * - One Route can be assigned to MANY Buses (one-to-many).
 *
 * @OneToMany: One route has many stops.
 * cascade = CascadeType.ALL: When you save/delete a Route,
 *   its stops are also saved/deleted automatically.
 * orphanRemoval = true: If a stop is removed from the list,
 *   it is automatically deleted from the database.
 * mappedBy = "route": The "route" field in RouteStop owns the FK.
 */
@Entity
@Table(name = "routes")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class Route {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "route_name", nullable = false, length = 150)
    private String routeName;

    /** Short code like "R-01". Must be unique. */
    @Column(name = "route_code", nullable = false, unique = true, length = 20)
    private String routeCode;

    @Column(columnDefinition = "TEXT")
    private String description;

    @Column(name = "start_location", nullable = false, length = 200)
    private String startLocation;

    @Column(name = "end_location", nullable = false, length = 200)
    private String endLocation;

    /** Distance in kilometres. DECIMAL(8,2) in MySQL. */
    @Column(name = "total_distance", precision = 8, scale = 2)
    private BigDecimal totalDistance;

    /** Estimated travel time in minutes */
    @Column(name = "estimated_time")
    private Integer estimatedTime;

    @Column(name = "is_active", nullable = false)
    @Builder.Default
    private Boolean isActive = true;

    /**
     * List of stops along this route.
     * FetchType.LAZY: stops are loaded only when accessed.
     * This avoids loading all stops whenever a Route is loaded.
     */
    @OneToMany(mappedBy = "route", cascade = CascadeType.ALL,
               orphanRemoval = true, fetch = FetchType.LAZY)
    @OrderBy("stopSequence ASC")  // Always return stops in sequence order
    @Builder.Default
    @ToString.Exclude
    private List<RouteStop> stops = new ArrayList<>();

    @CreationTimestamp
    @Column(name = "created_at", nullable = false, updatable = false)
    private LocalDateTime createdAt;

    @UpdateTimestamp
    @Column(name = "updated_at", nullable = false)
    private LocalDateTime updatedAt;
}
