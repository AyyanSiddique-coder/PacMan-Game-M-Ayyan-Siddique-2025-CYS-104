package com.university.bustracker.repository;

import com.university.bustracker.model.Route;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

/** RouteRepository — DB access for Route entities. */
@Repository
public interface RouteRepository extends JpaRepository<Route, Long> {

    Optional<Route> findByRouteCode(String routeCode);

    boolean existsByRouteCode(String routeCode);

    List<Route> findByIsActiveTrue();

    long countByIsActiveTrue();
}
