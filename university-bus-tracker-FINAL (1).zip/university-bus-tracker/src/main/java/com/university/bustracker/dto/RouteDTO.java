package com.university.bustracker.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.util.List;

/**
 * RouteDTO.java
 * Data transfer object for Route information.
 * Includes the list of stops for detailed view.
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class RouteDTO {

    private Long id;
    private String routeName;
    private String routeCode;
    private String description;
    private String startLocation;
    private String endLocation;
    private BigDecimal totalDistance;
    private Integer estimatedTime;
    private Boolean isActive;

    /** Stops along this route, in sequence order */
    private List<StopDTO> stops;

    /** Number of buses currently on this route */
    private Integer activeBusCount;

    /**
     * Nested DTO for route stops.
     * Using a nested static class keeps it all in one file.
     */
    @Data
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    public static class StopDTO {
        private Long id;
        private String stopName;
        private Integer stopSequence;
        private BigDecimal latitude;
        private BigDecimal longitude;
    }
}
