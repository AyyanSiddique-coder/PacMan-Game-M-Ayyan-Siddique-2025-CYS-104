package com.university.bustracker.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.time.LocalDateTime;

/**
 * BusDTO.java
 * Used for both creating buses (request) and returning bus info (response).
 * When used as a response, fields like id, routeName are populated.
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class BusDTO {

    private Long id;

    @NotBlank(message = "Bus number is required")
    private String busNumber;

    @NotBlank(message = "Number plate is required")
    private String numberPlate;

    @NotNull
    @Positive(message = "Capacity must be positive")
    private Integer capacity;

    private String busModel;
    private String status;
    private Long routeId;

    /** Populated from the related Route entity for response DTOs */
    private String routeName;
    private String routeCode;

    /** Current driver info */
    private String driverName;
    private Long driverId;

    /** Is there an active trip right now? */
    private Boolean hasActiveTrip;

    /** Latest GPS location (for map display) */
    private BigDecimal latitude;
    private BigDecimal longitude;
    private LocalDateTime lastLocationTime;
}
