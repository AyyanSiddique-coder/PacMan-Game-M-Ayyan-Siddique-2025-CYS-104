package com.university.bustracker.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import lombok.*;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import java.time.LocalDateTime;

/**
 * Driver.java — JPA Entity
 * =========================
 * Maps to the "drivers" table.
 *
 * Key relationship:
 * - Each driver is OPTIONALLY assigned one Bus (Many-to-One).
 *   A driver without a bus has bus_id = NULL in the database.
 *
 * @ManyToOne: Multiple drivers could theoretically share a bus,
 *             but in this system each bus has one active driver.
 * @JoinColumn: Specifies the foreign key column in the drivers table.
 * FetchType.LAZY: The Bus object is only loaded from DB when you
 *                 explicitly call driver.getBus(). This is more
 *                 efficient than EAGER which always loads it.
 */
@Entity
@Table(name = "drivers")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class Driver {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @NotBlank(message = "Name is required")
    @Column(nullable = false, length = 100)
    private String name;

    @Email(message = "Invalid email format")
    @NotBlank(message = "Email is required")
    @Column(nullable = false, unique = true, length = 150)
    private String email;

    @NotBlank(message = "Password is required")
    @Column(nullable = false, length = 255)
    private String password;

    @Column(length = 20)
    private String phone;

    /** Government-issued driver's license number */
    @Column(name = "license_number", unique = true, length = 50)
    private String licenseNumber;

    @Column(nullable = false, length = 30)
    @Builder.Default
    private String role = "ROLE_DRIVER";

    /**
     * The bus assigned to this driver.
     * FetchType.LAZY = don't load Bus unless needed.
     * @ToString.Exclude prevents infinite recursion when
     * both Driver and Bus reference each other (circular reference).
     */
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "bus_id")
    @ToString.Exclude
    private Bus bus;

    @Column(name = "is_active", nullable = false)
    @Builder.Default
    private Boolean isActive = true;

    @CreationTimestamp
    @Column(name = "created_at", nullable = false, updatable = false)
    private LocalDateTime createdAt;

    @UpdateTimestamp
    @Column(name = "updated_at", nullable = false)
    private LocalDateTime updatedAt;
}
