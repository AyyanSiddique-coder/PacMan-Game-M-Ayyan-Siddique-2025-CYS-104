package com.university.bustracker.controller;

import com.university.bustracker.dto.AdminDTO;
import com.university.bustracker.dto.ApiResponse;
import com.university.bustracker.dto.DriverDTO;
import com.university.bustracker.service.AdminService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

/**
 * AdminController - All admin-only management endpoints.
 * Secured to ROLE_ADMIN in SecurityConfig.
 *
 * BUG FIX #3: Added POST /api/admin/admins endpoint to create
 * new admin accounts with properly BCrypt-hashed passwords.
 */
@RestController
@RequestMapping("/api/admin")
@CrossOrigin(origins = "*")
public class AdminController {

    @Autowired
    private AdminService adminService;

    /** GET /api/admin/dashboard - System statistics */
    @GetMapping("/dashboard")
    public ResponseEntity<ApiResponse<Map<String, Object>>> getDashboard() {
        return ResponseEntity.ok(ApiResponse.success("Dashboard data", adminService.getDashboardStats()));
    }

    /** GET /api/admin/drivers - All drivers */
    @GetMapping("/drivers")
    public ResponseEntity<ApiResponse<List<DriverDTO>>> getAllDrivers() {
        return ResponseEntity.ok(ApiResponse.success("Drivers fetched", adminService.getAllDrivers()));
    }

    /** GET /api/admin/drivers/{id} */
    @GetMapping("/drivers/{id}")
    public ResponseEntity<ApiResponse<DriverDTO>> getDriver(@PathVariable Long id) {
        try {
            return ResponseEntity.ok(ApiResponse.success("Driver fetched", adminService.getDriverById(id)));
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(ApiResponse.error(e.getMessage()));
        }
    }

    /** POST /api/admin/drivers - Create new driver */
    @PostMapping("/drivers")
    public ResponseEntity<ApiResponse<DriverDTO>> createDriver(@RequestBody DriverDTO dto) {
        try {
            return ResponseEntity.status(HttpStatus.CREATED)
                    .body(ApiResponse.success("Driver created", adminService.createDriver(dto)));
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(ApiResponse.error(e.getMessage()));
        }
    }

    /** PUT /api/admin/drivers/{id} */
    @PutMapping("/drivers/{id}")
    public ResponseEntity<ApiResponse<DriverDTO>> updateDriver(@PathVariable Long id, @RequestBody DriverDTO dto) {
        try {
            return ResponseEntity.ok(ApiResponse.success("Driver updated", adminService.updateDriver(id, dto)));
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(ApiResponse.error(e.getMessage()));
        }
    }

    /** DELETE /api/admin/drivers/{id} */
    @DeleteMapping("/drivers/{id}")
    public ResponseEntity<ApiResponse<Void>> deleteDriver(@PathVariable Long id) {
        try {
            adminService.deleteDriver(id);
            return ResponseEntity.ok(ApiResponse.success("Driver deleted"));
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(ApiResponse.error(e.getMessage()));
        }
    }

    /**
     * POST /api/admin/admins - Create a new Admin account.
     *
     * BUG FIX #3: Previously, admin accounts could only be created by
     * inserting raw SQL with a manually crafted BCrypt hash — which was
     * broken (see Bug #1). This endpoint hashes the password correctly
     * at runtime using BCryptPasswordEncoder.
     *
     * Only an existing Admin (ROLE_ADMIN) can call this.
     * This is already enforced by .requestMatchers("/api/admin/**").hasRole("ADMIN")
     * in SecurityConfig.
     *
     * Request body:
     * {
     *   "name": "New Admin",
     *   "email": "newadmin@university.edu",
     *   "password": "securepass",
     *   "phone": "0300-0000000"
     * }
     */
    @PostMapping("/admins")
    public ResponseEntity<ApiResponse<AdminDTO>> createAdmin(@RequestBody AdminDTO dto) {
        try {
            return ResponseEntity.status(HttpStatus.CREATED)
                    .body(ApiResponse.success("Admin created", adminService.createAdmin(dto)));
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(ApiResponse.error(e.getMessage()));
        }
    }
}
