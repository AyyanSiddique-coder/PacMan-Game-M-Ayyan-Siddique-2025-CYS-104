package com.university.bustracker.dto;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;
import lombok.Data;

/**
 * StudentRegisterRequest.java — DTO
 * ===================================
 * Received from the browser when a student signs up.
 * {
 *   "name": "Ali Raza",
 *   "email": "ali@student.edu",
 *   "password": "securepass",
 *   "studentId": "CS-2021-001",
 *   "phone": "0321-1111111",
 *   "department": "Computer Science"
 * }
 */
@Data
public class StudentRegisterRequest {

    @NotBlank(message = "Name is required")
    @Size(min = 2, max = 100, message = "Name must be 2-100 characters")
    private String name;

    @Email(message = "Valid email required")
    @NotBlank(message = "Email is required")
    private String email;

    @NotBlank(message = "Password is required")
    @Size(min = 6, message = "Password must be at least 6 characters")
    private String password;

    private String studentId;
    private String phone;
    private String department;
}
