package com.university.bustracker.controller;

import com.university.bustracker.dto.ApiResponse;
import com.university.bustracker.model.Notification;
import com.university.bustracker.model.Student;
import com.university.bustracker.repository.NotificationRepository;
import com.university.bustracker.repository.StudentRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

/**
 * StudentController.java
 * =======================
 * Endpoints available to logged-in students.
 * All routes under /api/student/** require ROLE_STUDENT.
 */
@RestController
@RequestMapping("/api/student")
@CrossOrigin(origins = "*")
public class StudentController {

    @Autowired
    private StudentRepository studentRepository;

    @Autowired
    private NotificationRepository notificationRepository;

    /**
     * GET /api/student/profile
     * Returns the logged-in student's own profile.
     * Authentication.getName() gives the email from the JWT.
     */
    @GetMapping("/profile")
    public ResponseEntity<ApiResponse<Map<String, Object>>> getProfile(Authentication authentication) {
        return studentRepository.findByEmail(authentication.getName())
                .map(student -> {
                    // Build a safe response — no password field
                    Map<String, Object> profile = Map.of(
                        "id", student.getId(),
                        "name", student.getName(),
                        "email", student.getEmail(),
                        "studentId", student.getStudentId() != null ? student.getStudentId() : "",
                        "phone", student.getPhone() != null ? student.getPhone() : "",
                        "department", student.getDepartment() != null ? student.getDepartment() : "",
                        "role", student.getRole(),
                        "createdAt", student.getCreatedAt()
                    );
                    return ResponseEntity.ok(ApiResponse.success("Profile fetched", profile));
                })
                .orElse(ResponseEntity.notFound().build());
    }

    /**
     * GET /api/student/notifications
     * Returns notifications relevant to students.
     */
    @GetMapping("/notifications")
    public ResponseEntity<ApiResponse<List<Notification>>> getNotifications() {
        List<Notification> notes = notificationRepository.findByRoleOrGlobal("ROLE_STUDENT");
        return ResponseEntity.ok(ApiResponse.success("Notifications fetched", notes));
    }
}
