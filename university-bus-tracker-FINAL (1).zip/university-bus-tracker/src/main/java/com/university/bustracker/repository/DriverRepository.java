package com.university.bustracker.repository;

import com.university.bustracker.model.Driver;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

/**
 * DriverRepository.java
 * Provides DB access for Driver entities.
 */
@Repository
public interface DriverRepository extends JpaRepository<Driver, Long> {

    Optional<Driver> findByEmail(String email);

    boolean existsByEmail(String email);

    /** Find all active drivers */
    List<Driver> findByIsActiveTrue();

    /** Find driver assigned to a specific bus */
    Optional<Driver> findByBusId(Long busId);

    /** Count active drivers for dashboard stats */
    long countByIsActiveTrue();
}
