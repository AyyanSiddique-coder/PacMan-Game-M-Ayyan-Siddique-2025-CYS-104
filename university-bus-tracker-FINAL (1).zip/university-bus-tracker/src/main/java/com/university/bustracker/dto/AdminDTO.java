package com.university.bustracker.dto;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

/**
 * AdminDTO.java
 * =============
 * BUG FIX #3: New DTO to allow creating Admin accounts via API.
 * Previously there was no way to create an Admin except via raw SQL,
 * and the SQL seed hashes were broken (Bug #1).
 *
 * Used by:  POST /api/auth/register-admin
 * Secured:  ROLE_ADMIN only (only an existing admin can create another)
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class AdminDTO {

    private Long id;

    @NotBlank(message = "Name is required")
    private String name;

    @Email(message = "Valid email required")
    @NotBlank(message = "Email is required")
    private String email;

    /** Only used on creation. Never returned in responses. */
    private String password;

    private String phone;
    private Boolean isActive;
    private LocalDateTime createdAt;
}
