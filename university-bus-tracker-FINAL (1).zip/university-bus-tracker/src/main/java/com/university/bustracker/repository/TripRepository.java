package com.university.bustracker.repository;

import com.university.bustracker.model.Trip;
import com.university.bustracker.model.Trip.TripStatus;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

/**
 * TripRepository — DB access for Trip entities.
 */
@Repository
public interface TripRepository extends JpaRepository<Trip, Long> {

    /**
     * Find the currently ACTIVE trip for a driver.
     * A driver should only have one active trip at a time.
     * "STARTED" or "IN_PROGRESS" = active.
     */
    Optional<Trip> findByDriverIdAndStatusIn(Long driverId, List<TripStatus> statuses);

    /**
     * Find the active trip for a specific bus.
     * Students use this to check if a bus is currently running.
     */
    Optional<Trip> findByBusIdAndStatusIn(Long busId, List<TripStatus> statuses);

    /** All trips by a driver, most recent first */
    List<Trip> findByDriverIdOrderByStartTimeDesc(Long driverId);

    /** Count completed trips for admin statistics */
    long countByStatus(TripStatus status);
}
