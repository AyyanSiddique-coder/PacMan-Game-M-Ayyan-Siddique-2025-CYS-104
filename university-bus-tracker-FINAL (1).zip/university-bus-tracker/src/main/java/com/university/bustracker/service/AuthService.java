package com.university.bustracker.service;

import com.university.bustracker.dto.*;
import com.university.bustracker.model.Admin;
import com.university.bustracker.model.Driver;
import com.university.bustracker.model.Student;
import com.university.bustracker.repository.AdminRepository;
import com.university.bustracker.repository.DriverRepository;
import com.university.bustracker.repository.StudentRepository;
import com.university.bustracker.security.JwtTokenProvider;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

/**
 * AuthService.java
 * =================
 * Handles login and registration logic.
 *
 * The login flow:
 * 1. Browser sends POST /api/auth/login with {email, password, role}
 * 2. AuthController calls authService.login()
 * 3. AuthService asks AuthenticationManager to verify credentials
 * 4. AuthenticationManager uses BCrypt to check the hashed password
 * 5. If valid, we generate a JWT token
 * 6. Return JWT + user info to browser
 *
 * The AuthenticationManager handles the actual password verification.
 * We don't manually compare passwords — Spring Security does it safely.
 */
@Service
public class AuthService {

    @Autowired
    private AuthenticationManager authenticationManager;

    @Autowired
    private JwtTokenProvider tokenProvider;

    @Autowired
    private StudentRepository studentRepository;

    @Autowired
    private DriverRepository driverRepository;

    @Autowired
    private AdminRepository adminRepository;

    @Autowired
    private PasswordEncoder passwordEncoder;

    /**
     * Authenticates a user and returns a JWT token.
     *
     * @param loginRequest contains email, password, role
     * @return LoginResponse with JWT token and user info
     */
    public LoginResponse login(LoginRequest loginRequest) {

        // Spring Security's AuthenticationManager handles password verification.
        // It calls CustomUserDetailsService.loadUserByUsername(email),
        // gets the stored BCrypt hash, and compares it with the provided password.
        // If they don't match, it throws BadCredentialsException.
        Authentication authentication = authenticationManager.authenticate(
            new UsernamePasswordAuthenticationToken(
                loginRequest.getEmail(),
                loginRequest.getPassword()
            )
        );

        // Store authentication in SecurityContext (for this request's lifetime)
        SecurityContextHolder.getContext().setAuthentication(authentication);

        // Generate JWT token
        String jwt = tokenProvider.generateToken(authentication);

        // Build the response based on which role logged in
        String role = loginRequest.getRole().toUpperCase();

        return switch (role) {
            case "STUDENT" -> {
                Student student = studentRepository.findByEmail(loginRequest.getEmail())
                    .orElseThrow(() -> new RuntimeException("Student not found"));
                yield LoginResponse.builder()
                        .token(jwt)
                        .tokenType("Bearer")
                        .userId(student.getId())
                        .name(student.getName())
                        .email(student.getEmail())
                        .role(student.getRole())
                        .expiresIn(tokenProvider.getJwtExpirationMs() / 1000)
                        .build();
            }
            case "DRIVER" -> {
                Driver driver = driverRepository.findByEmail(loginRequest.getEmail())
                    .orElseThrow(() -> new RuntimeException("Driver not found"));
                yield LoginResponse.builder()
                        .token(jwt)
                        .tokenType("Bearer")
                        .userId(driver.getId())
                        .name(driver.getName())
                        .email(driver.getEmail())
                        .role(driver.getRole())
                        .expiresIn(tokenProvider.getJwtExpirationMs() / 1000)
                        .build();
            }
            case "ADMIN" -> {
                Admin admin = adminRepository.findByEmail(loginRequest.getEmail())
                    .orElseThrow(() -> new RuntimeException("Admin not found"));
                yield LoginResponse.builder()
                        .token(jwt)
                        .tokenType("Bearer")
                        .userId(admin.getId())
                        .name(admin.getName())
                        .email(admin.getEmail())
                        .role(admin.getRole())
                        .expiresIn(tokenProvider.getJwtExpirationMs() / 1000)
                        .build();
            }
            default -> throw new RuntimeException("Invalid role: " + role);
        };
    }

    /**
     * Registers a new student account.
     * Validates:
     * - Email is not already registered
     * - Student ID is not already used
     *
     * @param request registration form data
     * @return the created Student entity
     */
    public Student registerStudent(StudentRegisterRequest request) {

        // Check for duplicate email
        if (studentRepository.existsByEmail(request.getEmail())) {
            throw new RuntimeException("Email is already registered: " + request.getEmail());
        }

        // Check for duplicate student ID
        if (request.getStudentId() != null && !request.getStudentId().isBlank()
                && studentRepository.existsByStudentId(request.getStudentId())) {
            throw new RuntimeException("Student ID is already registered: " + request.getStudentId());
        }

        // Create the Student entity.
        // IMPORTANT: We hash the password before saving.
        // NEVER save plain text passwords!
        Student student = Student.builder()
                .name(request.getName())
                .email(request.getEmail())
                .password(passwordEncoder.encode(request.getPassword()))  // BCrypt hash
                .studentId(request.getStudentId())
                .phone(request.getPhone())
                .department(request.getDepartment())
                .role("ROLE_STUDENT")
                .isActive(true)
                .build();

        return studentRepository.save(student);
    }
}
