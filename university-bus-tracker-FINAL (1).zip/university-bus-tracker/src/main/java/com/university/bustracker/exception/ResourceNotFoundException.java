package com.university.bustracker.exception;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

/**
 * ResourceNotFoundException.java
 * =================================
 * Thrown when an entity is not found in the database.
 * For example: busRepository.findById(999) → not found → throw this.
 *
 * @ResponseStatus(HttpStatus.NOT_FOUND): When this exception bubbles up
 * to the controller without being caught, Spring automatically returns
 * a 404 HTTP response. The GlobalExceptionHandler also catches it.
 */
@ResponseStatus(HttpStatus.NOT_FOUND)
public class ResourceNotFoundException extends RuntimeException {

    private final String resourceName;
    private final String fieldName;
    private final Object fieldValue;

    public ResourceNotFoundException(String resourceName, String fieldName, Object fieldValue) {
        super(String.format("%s not found with %s: '%s'", resourceName, fieldName, fieldValue));
        this.resourceName = resourceName;
        this.fieldName = fieldName;
        this.fieldValue = fieldValue;
    }

    public ResourceNotFoundException(String message) {
        super(message);
        this.resourceName = "";
        this.fieldName = "";
        this.fieldValue = "";
    }

    public String getResourceName() { return resourceName; }
    public String getFieldName() { return fieldName; }
    public Object getFieldValue() { return fieldValue; }
}
