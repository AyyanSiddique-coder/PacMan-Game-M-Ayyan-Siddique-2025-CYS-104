package com.university.bustracker.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * ApiResponse.java — Generic API Response Wrapper
 * =================================================
 * Every REST endpoint returns this object (or a subtype).
 * This gives the frontend a consistent response structure:
 *
 * Success:
 * {
 *   "success": true,
 *   "message": "Bus created successfully",
 *   "data": { ... actual payload ... }
 * }
 *
 * Error:
 * {
 *   "success": false,
 *   "message": "Bus not found",
 *   "data": null
 * }
 *
 * @param <T> The type of the data payload (Bus, Student, List<Route>, etc.)
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class ApiResponse<T> {

    private boolean success;
    private String message;
    private T data;

    /** Quick factory for success responses with data */
    public static <T> ApiResponse<T> success(String message, T data) {
        return ApiResponse.<T>builder()
                .success(true)
                .message(message)
                .data(data)
                .build();
    }

    /** Quick factory for success responses without data */
    public static <T> ApiResponse<T> success(String message) {
        return ApiResponse.<T>builder()
                .success(true)
                .message(message)
                .build();
    }

    /** Quick factory for error responses */
    public static <T> ApiResponse<T> error(String message) {
        return ApiResponse.<T>builder()
                .success(false)
                .message(message)
                .build();
    }
}
