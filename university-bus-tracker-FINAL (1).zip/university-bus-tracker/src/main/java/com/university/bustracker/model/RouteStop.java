package com.university.bustracker.model;

import jakarta.persistence.*;
import lombok.*;

import java.math.BigDecimal;

/**
 * RouteStop.java — JPA Entity
 * ============================
 * Maps to the "route_stops" table.
 * Each row is one stop (pickup/drop point) on a route.
 *
 * Relationship: Many stops belong to ONE route.
 * @ManyToOne: Many RouteStops → One Route.
 * @JoinColumn(name = "route_id"): The FK column in route_stops table.
 */
@Entity
@Table(name = "route_stops")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class RouteStop {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    /**
     * The route this stop belongs to.
     * FetchType.LAZY: Don't load the full Route object unless needed.
     * @ToString.Exclude: Prevents infinite loop in toString()
     *   when Route.toString() calls RouteStop.toString() which calls Route...
     */
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "route_id", nullable = false)
    @ToString.Exclude
    private Route route;

    @Column(name = "stop_name", nullable = false, length = 150)
    private String stopName;

    /**
     * The position of this stop in the route sequence.
     * Stop 1 = first pickup, Stop N = last (destination).
     */
    @Column(name = "stop_sequence", nullable = false)
    private Integer stopSequence;

    /** GPS latitude of this stop. DECIMAL(10,8) for precision. */
    @Column(precision = 10, scale = 8)
    private BigDecimal latitude;

    /** GPS longitude. DECIMAL(11,8) allows values like -179.12345678 */
    @Column(precision = 11, scale = 8)
    private BigDecimal longitude;
}
