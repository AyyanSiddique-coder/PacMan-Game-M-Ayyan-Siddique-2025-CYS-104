package com.university.bustracker.config;

import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.ResourceHandlerRegistry;
import org.springframework.web.servlet.config.annotation.ViewControllerRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

/**
 * WebConfig.java
 * ===============
 * Configures Spring MVC to serve static HTML pages.
 *
 * Without this, accessing /login.html directly would work (Spring Boot
 * auto-serves static files), but we also add explicit mappings here
 * for clarity and to support any URL rewrites needed.
 *
 * @Configuration: Spring loads this at startup.
 * WebMvcConfigurer: Interface that lets us customize Spring MVC behavior.
 */
@Configuration
public class WebConfig implements WebMvcConfigurer {

    /**
     * Maps URL paths to view names (HTML files in /static/).
     * This lets Spring MVC forward requests to the right HTML file.
     *
     * Example: GET /login → serves /static/login.html
     */
    @Override
    public void addViewControllers(ViewControllerRegistry registry) {
        registry.addRedirectViewController("/", "/index.html");
        registry.addRedirectViewController("/login", "/login.html");
        registry.addRedirectViewController("/student", "/student-dashboard.html");
        registry.addRedirectViewController("/driver", "/driver-dashboard.html");
        registry.addRedirectViewController("/admin", "/admin-dashboard.html");
    }

    /**
     * Ensures that static resources in /static/ are served correctly.
     * Spring Boot does this automatically, but we add it explicitly
     * for clarity and to handle the /css/, /js/, /images/ sub-paths.
     */
    @Override
    public void addResourceHandlers(ResourceHandlerRegistry registry) {
        registry.addResourceHandler("/css/**")
                .addResourceLocations("classpath:/static/css/");
        registry.addResourceHandler("/js/**")
                .addResourceLocations("classpath:/static/js/");
        registry.addResourceHandler("/images/**")
                .addResourceLocations("classpath:/static/images/");
        registry.addResourceHandler("/*.html")
                .addResourceLocations("classpath:/static/");
    }
}
