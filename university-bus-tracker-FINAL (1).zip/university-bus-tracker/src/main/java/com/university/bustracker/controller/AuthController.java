package com.university.bustracker.controller;

import com.university.bustracker.dto.*;
import com.university.bustracker.service.AuthService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

/**
 * AuthController.java
 * ====================
 * Handles authentication endpoints:
 * - POST /api/auth/login    → Login for all roles
 * - POST /api/auth/register → Student self-registration
 *
 * @RestController: Combines @Controller + @ResponseBody.
 *   Every method return value is serialized to JSON automatically.
 *
 * @RequestMapping("/api/auth"): All methods in this controller
 *   have URLs starting with /api/auth.
 *
 * @CrossOrigin: Allow requests from any origin (for development).
 */
@RestController
@RequestMapping("/api/auth")
@CrossOrigin(origins = "*")
public class AuthController {

    @Autowired
    private AuthService authService;

    /**
     * POST /api/auth/login
     * ====================
     * Request body (JSON):
     * {
     *   "email": "ali@student.edu",
     *   "password": "password123",
     *   "role": "STUDENT"
     * }
     *
     * Response (200 OK):
     * {
     *   "success": true,
     *   "message": "Login successful",
     *   "data": {
     *     "token": "eyJhbGci...",
     *     "tokenType": "Bearer",
     *     "userId": 1,
     *     "name": "Ali Raza",
     *     "email": "ali@student.edu",
     *     "role": "ROLE_STUDENT",
     *     "expiresIn": 86400
     *   }
     * }
     *
     * @Valid: Triggers validation of @NotBlank, @Email etc. in LoginRequest.
     *   If validation fails, Spring returns 400 Bad Request automatically.
     *
     * ResponseEntity<T>: Gives us control over the HTTP status code.
     */
    @PostMapping("/login")
    public ResponseEntity<ApiResponse<LoginResponse>> login(
            @Valid @RequestBody LoginRequest loginRequest) {
        try {
            LoginResponse response = authService.login(loginRequest);
            return ResponseEntity.ok(
                ApiResponse.success("Login successful", response)
            );
        } catch (Exception e) {
            // BadCredentialsException, UsernameNotFoundException, etc.
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED)
                    .body(ApiResponse.error("Invalid credentials: " + e.getMessage()));
        }
    }

    /**
     * POST /api/auth/register
     * ========================
     * Student self-registration.
     * Request body:
     * {
     *   "name": "Ali Raza",
     *   "email": "ali@student.edu",
     *   "password": "securepass",
     *   "studentId": "CS-2021-001",
     *   "phone": "0321-1111111",
     *   "department": "Computer Science"
     * }
     *
     * Response (201 Created):
     * {
     *   "success": true,
     *   "message": "Registration successful! You can now login.",
     *   "data": null
     * }
     *
     * HTTP 201 = Created (more semantically correct than 200 for new resources).
     */
    @PostMapping("/register")
    public ResponseEntity<ApiResponse<Void>> register(
            @Valid @RequestBody StudentRegisterRequest request) {
        try {
            authService.registerStudent(request);
            return ResponseEntity.status(HttpStatus.CREATED)
                    .body(ApiResponse.success("Registration successful! You can now login."));
        } catch (Exception e) {
            return ResponseEntity.badRequest()
                    .body(ApiResponse.error(e.getMessage()));
        }
    }
}
