package com.university.bustracker.service;

import com.university.bustracker.dto.BusDTO;
import com.university.bustracker.model.Bus;
import com.university.bustracker.model.Bus.BusStatus;
import com.university.bustracker.model.BusLocation;
import com.university.bustracker.model.Driver;
import com.university.bustracker.model.Route;
import com.university.bustracker.model.Trip;
import com.university.bustracker.repository.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

/**
 * BusService.java
 * ================
 * Business logic for bus management.
 * Sits between BusController (API layer) and BusRepository (DB layer).
 *
 * @Service: Marks this as a Spring service component.
 * @Transactional: Database operations within methods are wrapped in a
 *   transaction. If an exception occurs, all changes are rolled back.
 */
@Service
@Transactional
public class BusService {

    @Autowired
    private BusRepository busRepository;

    @Autowired
    private RouteRepository routeRepository;

    @Autowired
    private DriverRepository driverRepository;

    @Autowired
    private BusLocationRepository busLocationRepository;

    @Autowired
    private TripRepository tripRepository;

    /**
     * Get all buses as DTOs.
     * Uses Java Streams to convert List<Bus> → List<BusDTO>.
     * The @Transactional(readOnly = true) hint allows Hibernate to
     * optimize the query since no data will be changed.
     */
    @Transactional(readOnly = true)
    public List<BusDTO> getAllBuses() {
        return busRepository.findAll()
                .stream()
                .map(this::convertToDTO)
                .collect(Collectors.toList());
    }

    /**
     * Get a single bus by ID.
     * orElseThrow() is the idiomatic way to handle "not found" cases.
     */
    @Transactional(readOnly = true)
    public BusDTO getBusById(Long id) {
        Bus bus = busRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Bus not found with id: " + id));
        return convertToDTO(bus);
    }

    /** Get all currently ACTIVE buses */
    @Transactional(readOnly = true)
    public List<BusDTO> getActiveBuses() {
        return busRepository.findByStatus(BusStatus.ACTIVE)
                .stream()
                .map(this::convertToDTO)
                .collect(Collectors.toList());
    }

    /**
     * Create a new bus. Admin only.
     * Validates uniqueness of bus number and plate.
     */
    public BusDTO createBus(BusDTO dto) {
        // Validate uniqueness
        if (busRepository.existsByBusNumber(dto.getBusNumber())) {
            throw new RuntimeException("Bus number already exists: " + dto.getBusNumber());
        }
        if (busRepository.existsByNumberPlate(dto.getNumberPlate())) {
            throw new RuntimeException("Number plate already exists: " + dto.getNumberPlate());
        }

        Bus bus = Bus.builder()
                .busNumber(dto.getBusNumber())
                .numberPlate(dto.getNumberPlate())
                .capacity(dto.getCapacity())
                .busModel(dto.getBusModel())
                .status(dto.getStatus() != null
                    ? BusStatus.valueOf(dto.getStatus())
                    : BusStatus.ACTIVE)
                .build();

        // Assign route if provided
        if (dto.getRouteId() != null) {
            Route route = routeRepository.findById(dto.getRouteId())
                    .orElseThrow(() -> new RuntimeException("Route not found"));
            bus.setRoute(route);
        }

        return convertToDTO(busRepository.save(bus));
    }

    /**
     * Update an existing bus.
     * Only updates fields that are provided (non-null).
     */
    public BusDTO updateBus(Long id, BusDTO dto) {
        Bus bus = busRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Bus not found with id: " + id));

        // Update only provided fields
        if (dto.getBusNumber() != null) bus.setBusNumber(dto.getBusNumber());
        if (dto.getNumberPlate() != null) bus.setNumberPlate(dto.getNumberPlate());
        if (dto.getCapacity() != null) bus.setCapacity(dto.getCapacity());
        if (dto.getBusModel() != null) bus.setBusModel(dto.getBusModel());
        if (dto.getStatus() != null) bus.setStatus(BusStatus.valueOf(dto.getStatus()));

        // Update route assignment
        if (dto.getRouteId() != null) {
            Route route = routeRepository.findById(dto.getRouteId())
                    .orElseThrow(() -> new RuntimeException("Route not found"));
            bus.setRoute(route);
        } else if (dto.getRouteId() == null && dto.getStatus() != null) {
            // If explicitly clearing route
            bus.setRoute(null);
        }

        return convertToDTO(busRepository.save(bus));
    }

    /**
     * Delete a bus by ID.
     * In production, consider soft-deleting (set status = INACTIVE) instead.
     */
    public void deleteBus(Long id) {
        if (!busRepository.existsById(id)) {
            throw new RuntimeException("Bus not found with id: " + id);
        }
        busRepository.deleteById(id);
    }

    /**
     * Assign a driver to a bus. Admin only.
     * Also clears the driver's old bus assignment.
     */
    public void assignDriverToBus(Long busId, Long driverId) {
        Bus bus = busRepository.findById(busId)
                .orElseThrow(() -> new RuntimeException("Bus not found"));
        Driver driver = driverRepository.findById(driverId)
                .orElseThrow(() -> new RuntimeException("Driver not found"));

        // Clear the old driver's bus assignment if they had one
        driverRepository.findByBusId(busId).ifPresent(oldDriver -> {
            oldDriver.setBus(null);
            driverRepository.save(oldDriver);
        });

        // Assign the new driver to this bus
        driver.setBus(bus);
        driverRepository.save(driver);
    }

    /**
     * Converts a Bus entity to a BusDTO.
     * Also enriches the DTO with:
     * - Latest GPS location
     * - Whether an active trip exists
     * - Driver info
     *
     * This method is called a "mapper" or "converter".
     */
    private BusDTO convertToDTO(Bus bus) {
        BusDTO dto = BusDTO.builder()
                .id(bus.getId())
                .busNumber(bus.getBusNumber())
                .numberPlate(bus.getNumberPlate())
                .capacity(bus.getCapacity())
                .busModel(bus.getBusModel())
                .status(bus.getStatus().name())
                .build();

        // Add route info if the bus is assigned to a route
        if (bus.getRoute() != null) {
            dto.setRouteId(bus.getRoute().getId());
            dto.setRouteName(bus.getRoute().getRouteName());
            dto.setRouteCode(bus.getRoute().getRouteCode());
        }

        // Add driver info
        driverRepository.findByBusId(bus.getId()).ifPresent(driver -> {
            dto.setDriverId(driver.getId());
            dto.setDriverName(driver.getName());
        });

        // Check if there's an active trip for this bus
        var activeStatuses = Arrays.asList(
            Trip.TripStatus.STARTED, Trip.TripStatus.IN_PROGRESS
        );
        boolean hasActiveTrip = tripRepository
                .findByBusIdAndStatusIn(bus.getId(), activeStatuses)
                .isPresent();
        dto.setHasActiveTrip(hasActiveTrip);

        // Add latest GPS location
        busLocationRepository.findLatestByBusId(bus.getId()).ifPresent(loc -> {
            dto.setLatitude(loc.getLatitude());
            dto.setLongitude(loc.getLongitude());
            dto.setLastLocationTime(loc.getRecordedAt());
        });

        return dto;
    }
}
