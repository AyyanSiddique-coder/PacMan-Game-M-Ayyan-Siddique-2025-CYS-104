package com.university.bustracker.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

/**
 * TripDTO.java — Response DTO for Trip information.
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class TripDTO {

    private Long id;
    private Long driverId;
    private String driverName;
    private Long busId;
    private String busNumber;
    private Long routeId;
    private String routeName;
    private String status;
    private LocalDateTime startTime;
    private LocalDateTime endTime;
    private String notes;
}
