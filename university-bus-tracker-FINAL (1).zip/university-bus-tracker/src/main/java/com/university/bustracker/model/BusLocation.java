package com.university.bustracker.model;

import jakarta.persistence.*;
import lombok.*;
import org.hibernate.annotations.CreationTimestamp;

import java.math.BigDecimal;
import java.time.LocalDateTime;

/**
 * BusLocation.java — JPA Entity
 * ==============================
 * Maps to the "bus_locations" table.
 * This is the CORE of live tracking.
 *
 * Every few seconds, the driver's browser sends GPS coordinates
 * to the backend. Each GPS ping is stored as a BusLocation row.
 *
 * Students fetch the LATEST BusLocation for a bus to see
 * where it currently is on the map.
 *
 * This table grows large over time. In production, you would:
 * - Archive old locations to a separate table
 * - Only keep the last N locations per bus
 * - Use a time-series database like TimescaleDB
 *
 * The database index idx_bus_recorded (bus_id, recorded_at DESC)
 * makes it fast to query "latest location for bus X".
 */
@Entity
@Table(name = "bus_locations",
       indexes = {
           @Index(name = "idx_bus_recorded",
                  columnList = "bus_id, recorded_at DESC")
       })
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class BusLocation {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    /** Which bus sent this GPS ping */
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "bus_id", nullable = false)
    @ToString.Exclude
    private Bus bus;

    /** Which trip this location was part of (can be null) */
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "trip_id")
    @ToString.Exclude
    private Trip trip;

    /**
     * GPS Latitude. Range: -90 to 90.
     * DECIMAL(10,8) gives 8 decimal places (~1mm precision).
     * Lahore latitude ≈ 31.5204
     */
    @Column(nullable = false, precision = 10, scale = 8)
    private BigDecimal latitude;

    /**
     * GPS Longitude. Range: -180 to 180.
     * DECIMAL(11,8) accommodates the extra digit needed for negatives.
     * Lahore longitude ≈ 74.3587
     */
    @Column(nullable = false, precision = 11, scale = 8)
    private BigDecimal longitude;

    /** Speed in km/h from the browser geolocation API */
    @Column(precision = 6, scale = 2)
    private BigDecimal speed;

    /** Direction in degrees (0 = North, 90 = East, 180 = South, 270 = West) */
    @Column(precision = 5, scale = 2)
    private BigDecimal heading;

    /** GPS accuracy radius in metres. Lower = more accurate. */
    @Column(precision = 8, scale = 2)
    private BigDecimal accuracy;

    /** When this GPS ping was recorded. Auto-set by Hibernate. */
    @CreationTimestamp
    @Column(name = "recorded_at", nullable = false, updatable = false)
    private LocalDateTime recordedAt;
}
