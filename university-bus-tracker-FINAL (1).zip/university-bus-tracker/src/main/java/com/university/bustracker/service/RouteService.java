package com.university.bustracker.service;

import com.university.bustracker.dto.RouteDTO;
import com.university.bustracker.model.Route;
import com.university.bustracker.model.RouteStop;
import com.university.bustracker.repository.BusRepository;
import com.university.bustracker.repository.RouteRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.stream.Collectors;

/**
 * RouteService.java
 * Business logic for route management.
 */
@Service
@Transactional
public class RouteService {

    @Autowired
    private RouteRepository routeRepository;

    @Autowired
    private BusRepository busRepository;

    @Transactional(readOnly = true)
    public List<RouteDTO> getAllRoutes() {
        return routeRepository.findAll()
                .stream()
                .map(this::convertToDTO)
                .collect(Collectors.toList());
    }

    @Transactional(readOnly = true)
    public List<RouteDTO> getActiveRoutes() {
        return routeRepository.findByIsActiveTrue()
                .stream()
                .map(this::convertToDTO)
                .collect(Collectors.toList());
    }

    @Transactional(readOnly = true)
    public RouteDTO getRouteById(Long id) {
        Route route = routeRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Route not found with id: " + id));
        return convertToDTO(route);
    }

    public RouteDTO createRoute(RouteDTO dto) {
        if (routeRepository.existsByRouteCode(dto.getRouteCode())) {
            throw new RuntimeException("Route code already exists: " + dto.getRouteCode());
        }

        Route route = Route.builder()
                .routeName(dto.getRouteName())
                .routeCode(dto.getRouteCode())
                .description(dto.getDescription())
                .startLocation(dto.getStartLocation())
                .endLocation(dto.getEndLocation())
                .totalDistance(dto.getTotalDistance())
                .estimatedTime(dto.getEstimatedTime())
                .isActive(true)
                .build();

        // Add stops if provided
        if (dto.getStops() != null) {
            for (RouteDTO.StopDTO stopDTO : dto.getStops()) {
                RouteStop stop = RouteStop.builder()
                        .route(route)
                        .stopName(stopDTO.getStopName())
                        .stopSequence(stopDTO.getStopSequence())
                        .latitude(stopDTO.getLatitude())
                        .longitude(stopDTO.getLongitude())
                        .build();
                route.getStops().add(stop);
            }
        }

        return convertToDTO(routeRepository.save(route));
    }

    public RouteDTO updateRoute(Long id, RouteDTO dto) {
        Route route = routeRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Route not found with id: " + id));

        if (dto.getRouteName() != null) route.setRouteName(dto.getRouteName());
        if (dto.getDescription() != null) route.setDescription(dto.getDescription());
        if (dto.getStartLocation() != null) route.setStartLocation(dto.getStartLocation());
        if (dto.getEndLocation() != null) route.setEndLocation(dto.getEndLocation());
        if (dto.getTotalDistance() != null) route.setTotalDistance(dto.getTotalDistance());
        if (dto.getEstimatedTime() != null) route.setEstimatedTime(dto.getEstimatedTime());
        if (dto.getIsActive() != null) route.setIsActive(dto.getIsActive());

        return convertToDTO(routeRepository.save(route));
    }

    public void deleteRoute(Long id) {
        if (!routeRepository.existsById(id)) {
            throw new RuntimeException("Route not found with id: " + id);
        }
        routeRepository.deleteById(id);
    }

    /** Converts Route entity → RouteDTO, including stops */
    private RouteDTO convertToDTO(Route route) {
        // Count buses on this route
        int activeBusCount = busRepository.findByRouteId(route.getId()).size();

        // Convert stops
        List<RouteDTO.StopDTO> stopDTOs = route.getStops().stream()
                .map(stop -> RouteDTO.StopDTO.builder()
                        .id(stop.getId())
                        .stopName(stop.getStopName())
                        .stopSequence(stop.getStopSequence())
                        .latitude(stop.getLatitude())
                        .longitude(stop.getLongitude())
                        .build())
                .collect(Collectors.toList());

        return RouteDTO.builder()
                .id(route.getId())
                .routeName(route.getRouteName())
                .routeCode(route.getRouteCode())
                .description(route.getDescription())
                .startLocation(route.getStartLocation())
                .endLocation(route.getEndLocation())
                .totalDistance(route.getTotalDistance())
                .estimatedTime(route.getEstimatedTime())
                .isActive(route.getIsActive())
                .stops(stopDTOs)
                .activeBusCount(activeBusCount)
                .build();
    }
}
