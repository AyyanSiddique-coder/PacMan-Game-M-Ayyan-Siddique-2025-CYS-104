package com.university.bustracker.dto;

import jakarta.validation.constraints.DecimalMax;
import jakarta.validation.constraints.DecimalMin;
import jakarta.validation.constraints.NotNull;
import lombok.Data;

import java.math.BigDecimal;

/**
 * LocationUpdateRequest.java
 * ===========================
 * Sent by the driver's browser every few seconds with GPS data.
 * The driver app calls navigator.geolocation.watchPosition() and
 * sends the coordinates to POST /api/location/update.
 *
 * Example JSON payload:
 * {
 *   "latitude": 31.5204,
 *   "longitude": 74.3587,
 *   "speed": 45.5,
 *   "heading": 180.0,
 *   "accuracy": 10.0
 * }
 */
@Data
public class LocationUpdateRequest {

    @NotNull(message = "Latitude is required")
    @DecimalMin(value = "-90.0", message = "Latitude must be >= -90")
    @DecimalMax(value = "90.0",  message = "Latitude must be <= 90")
    private BigDecimal latitude;

    @NotNull(message = "Longitude is required")
    @DecimalMin(value = "-180.0", message = "Longitude must be >= -180")
    @DecimalMax(value = "180.0",  message = "Longitude must be <= 180")
    private BigDecimal longitude;

    /** Speed in km/h. Null if GPS can't determine speed. */
    private BigDecimal speed;

    /** Direction in degrees (0=North, 90=East, etc.) */
    private BigDecimal heading;

    /** GPS accuracy radius in metres */
    private BigDecimal accuracy;

    /** The active trip ID this location belongs to */
    private Long tripId;
}
