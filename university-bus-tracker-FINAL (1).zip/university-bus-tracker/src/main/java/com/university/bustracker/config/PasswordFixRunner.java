package com.university.bustracker.config;

import com.university.bustracker.repository.AdminRepository;
import com.university.bustracker.repository.DriverRepository;
import com.university.bustracker.repository.StudentRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;

@Component
public class PasswordFixRunner implements CommandLineRunner {

    private static final Logger log = LoggerFactory.getLogger(PasswordFixRunner.class);
    private static final String DEFAULT_PASSWORD = "password123";

    @Autowired private PasswordEncoder passwordEncoder;
    @Autowired private AdminRepository adminRepository;
    @Autowired private DriverRepository driverRepository;
    @Autowired private StudentRepository studentRepository;

    @Override
    public void run(String... args) {
        log.info("PasswordFixRunner: fixing all accounts...");
        String correctHash = passwordEncoder.encode(DEFAULT_PASSWORD);

        // Fix ALL admins — force correct password AND is_active = true
        for (var admin : adminRepository.findAll()) {
            admin.setPassword(correctHash);
            admin.setIsActive(true);
            adminRepository.save(admin);
            log.info("  Fixed admin: {} -> is_active=true, password=password123", admin.getEmail());
        }

        // Fix ALL drivers — force correct password AND is_active = true
        for (var driver : driverRepository.findAll()) {
            driver.setPassword(correctHash);
            driver.setIsActive(true);
            driverRepository.save(driver);
            log.info("  Fixed driver: {} -> is_active=true", driver.getEmail());
        }

        // Fix ALL students — force correct password AND is_active = true
        for (var student : studentRepository.findAll()) {
            student.setPassword(correctHash);
            student.setIsActive(true);
            studentRepository.save(student);
            log.info("  Fixed student: {} -> is_active=true", student.getEmail());
        }

        log.info("PasswordFixRunner: DONE. All accounts active. Login with password123.");
    }
}
