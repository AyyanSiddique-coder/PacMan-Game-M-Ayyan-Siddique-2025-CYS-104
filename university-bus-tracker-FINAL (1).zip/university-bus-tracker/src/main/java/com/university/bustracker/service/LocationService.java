package com.university.bustracker.service;

import com.university.bustracker.dto.LocationUpdateRequest;
import com.university.bustracker.model.Bus;
import com.university.bustracker.model.BusLocation;
import com.university.bustracker.model.Driver;
import com.university.bustracker.model.Trip;
import com.university.bustracker.repository.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;

/**
 * LocationService.java
 * =====================
 * Handles GPS location updates from drivers and provides
 * location data to students.
 *
 * This is the HEART of the live tracking system.
 * It receives GPS pings from the driver's browser and stores them.
 * Students poll this service to get the latest bus positions.
 */
@Service
@Transactional
public class LocationService {

    @Autowired
    private BusLocationRepository busLocationRepository;

    @Autowired
    private DriverRepository driverRepository;

    @Autowired
    private BusRepository busRepository;

    @Autowired
    private TripRepository tripRepository;

    /**
     * Called by the driver's browser every few seconds with new GPS coordinates.
     *
     * Process:
     * 1. Find the driver making the request (by their email from JWT)
     * 2. Get their assigned bus
     * 3. Optionally link to active trip
     * 4. Save the GPS coordinates as a new BusLocation record
     *
     * @param driverEmail the email from the JWT token (identifies the driver)
     * @param request     GPS data from the browser
     * @return the saved BusLocation entity
     */
    public BusLocation updateLocation(String driverEmail, LocationUpdateRequest request) {

        // Find the driver by email (from their JWT token)
        Driver driver = driverRepository.findByEmail(driverEmail)
                .orElseThrow(() -> new RuntimeException("Driver not found: " + driverEmail));

        // Get the driver's assigned bus
        if (driver.getBus() == null) {
            throw new RuntimeException("Driver has no assigned bus. Please contact admin.");
        }
        Bus bus = driver.getBus();

        // Build the BusLocation entity
        BusLocation.BusLocationBuilder builder = BusLocation.builder()
                .bus(bus)
                .latitude(request.getLatitude())
                .longitude(request.getLongitude())
                .speed(request.getSpeed())
                .heading(request.getHeading())
                .accuracy(request.getAccuracy());

        // Link to active trip if trip ID is provided
        if (request.getTripId() != null) {
            tripRepository.findById(request.getTripId())
                    .ifPresent(builder::trip);
        } else {
            // Try to find the active trip automatically
            List<Trip.TripStatus> activeStatuses = Arrays.asList(
                Trip.TripStatus.STARTED, Trip.TripStatus.IN_PROGRESS
            );
            tripRepository.findByDriverIdAndStatusIn(driver.getId(), activeStatuses)
                    .ifPresent(trip -> {
                        builder.trip(trip);
                        // Advance status to IN_PROGRESS once we receive location
                        if (trip.getStatus() == Trip.TripStatus.STARTED) {
                            trip.setStatus(Trip.TripStatus.IN_PROGRESS);
                            tripRepository.save(trip);
                        }
                    });
        }

        BusLocation location = builder.build();
        return busLocationRepository.save(location);
    }

    /**
     * Get the latest GPS location for a specific bus.
     * Returns Optional — students handle the case where no location exists.
     */
    @Transactional(readOnly = true)
    public Optional<BusLocation> getLatestLocation(Long busId) {
        return busLocationRepository.findLatestByBusId(busId);
    }

    /**
     * Get the latest location for ALL buses.
     * Used by the student map to show all buses simultaneously.
     */
    @Transactional(readOnly = true)
    public List<BusLocation> getAllLatestLocations() {
        return busLocationRepository.findLatestLocationForAllBuses();
    }

    /**
     * Get recent location trail for a bus (last 20 points).
     * Used to draw a path showing where the bus has been.
     */
    @Transactional(readOnly = true)
    public List<BusLocation> getRecentLocations(Long busId, int limit) {
        return busLocationRepository.findRecentByBusId(busId, limit);
    }
}
