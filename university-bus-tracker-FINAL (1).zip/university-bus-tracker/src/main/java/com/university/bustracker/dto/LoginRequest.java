package com.university.bustracker.dto;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;
import lombok.Data;

/**
 * LoginRequest.java — DTO
 * ========================
 * DTOs (Data Transfer Objects) are simple classes that carry
 * data between the frontend and backend.
 *
 * WHY use DTOs instead of sending the entity directly?
 * - Security: Never expose password hashes, internal IDs, etc.
 * - Flexibility: API shape can differ from database shape.
 * - Validation: @NotBlank, @Email etc. validate incoming JSON.
 *
 * This DTO is sent by the browser as JSON when a user logs in:
 * {
 *   "email": "ali@student.edu",
 *   "password": "password123",
 *   "role": "STUDENT"
 * }
 */
@Data
public class LoginRequest {

    @Email(message = "Please provide a valid email address")
    @NotBlank(message = "Email is required")
    private String email;

    @NotBlank(message = "Password is required")
    @Size(min = 6, message = "Password must be at least 6 characters")
    private String password;

    /**
     * Role helps us know which table to look up:
     * "STUDENT", "DRIVER", or "ADMIN"
     */
    @NotBlank(message = "Role is required")
    private String role;
}
