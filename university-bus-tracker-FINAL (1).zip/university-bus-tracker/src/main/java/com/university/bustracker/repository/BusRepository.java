package com.university.bustracker.repository;

import com.university.bustracker.model.Bus;
import com.university.bustracker.model.Bus.BusStatus;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

/**
 * BusRepository — DB access for Bus entities.
 */
@Repository
public interface BusRepository extends JpaRepository<Bus, Long> {

    Optional<Bus> findByBusNumber(String busNumber);

    boolean existsByBusNumber(String busNumber);

    boolean existsByNumberPlate(String numberPlate);

    /** Get all buses with a specific status */
    List<Bus> findByStatus(BusStatus status);

    /** Get all buses on a specific route */
    List<Bus> findByRouteId(Long routeId);

    /** Search by bus number (partial match, case-insensitive) */
    @Query("SELECT b FROM Bus b WHERE LOWER(b.busNumber) LIKE LOWER(CONCAT('%', :keyword, '%'))")
    List<Bus> searchByBusNumber(String keyword);

    long countByStatus(BusStatus status);
}
