package com.university.bustracker.controller;

import com.university.bustracker.dto.ApiResponse;
import com.university.bustracker.dto.TripDTO;
import com.university.bustracker.service.TripService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * DriverController - Driver-specific endpoints.
 * Secured to ROLE_DRIVER.
 */
@RestController
@RequestMapping("/api/driver")
@CrossOrigin(origins = "*")
public class DriverController {

    @Autowired
    private TripService tripService;

    /** POST /api/driver/trip/start */
    @PostMapping("/trip/start")
    public ResponseEntity<ApiResponse<TripDTO>> startTrip(Authentication authentication) {
        try {
            TripDTO trip = tripService.startTrip(authentication.getName());
            return ResponseEntity.ok(ApiResponse.success("Trip started!", trip));
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(ApiResponse.error(e.getMessage()));
        }
    }

    /** POST /api/driver/trip/{tripId}/end */
    @PostMapping("/trip/{tripId}/end")
    public ResponseEntity<ApiResponse<TripDTO>> endTrip(
            @PathVariable Long tripId,
            Authentication authentication) {
        try {
            TripDTO trip = tripService.endTrip(authentication.getName(), tripId);
            return ResponseEntity.ok(ApiResponse.success("Trip ended successfully", trip));
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(ApiResponse.error(e.getMessage()));
        }
    }

    /** GET /api/driver/trip/active */
    @GetMapping("/trip/active")
    public ResponseEntity<ApiResponse<TripDTO>> getActiveTrip(Authentication authentication) {
        TripDTO trip = tripService.getActiveTrip(authentication.getName());
        if (trip != null) {
            return ResponseEntity.ok(ApiResponse.success("Active trip found", trip));
        }
        return ResponseEntity.ok(ApiResponse.success("No active trip", null));
    }

    /** GET /api/driver/trip/history */
    @GetMapping("/trip/history")
    public ResponseEntity<ApiResponse<List<TripDTO>>> getTripHistory(Authentication authentication) {
        List<TripDTO> history = tripService.getDriverTripHistory(authentication.getName());
        return ResponseEntity.ok(ApiResponse.success("Trip history fetched", history));
    }
}
