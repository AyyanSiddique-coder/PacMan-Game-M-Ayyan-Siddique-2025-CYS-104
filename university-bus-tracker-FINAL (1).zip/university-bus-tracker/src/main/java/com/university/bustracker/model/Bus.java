package com.university.bustracker.model;

import jakarta.persistence.*;
import lombok.*;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import java.time.LocalDateTime;

/**
 * Bus.java — JPA Entity
 * ======================
 * Maps to the "buses" table.
 * Each Bus has a unique number, plate, capacity, and status.
 *
 * Uses a Java Enum for the status field which maps to MySQL ENUM type.
 * EnumType.STRING stores the enum name as a string ("ACTIVE", not "0").
 */
@Entity
@Table(name = "buses")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class Bus {

    /**
     * Bus status options:
     * ACTIVE      = Bus is operational and running routes.
     * INACTIVE    = Bus is not currently assigned/used.
     * MAINTENANCE = Bus is under repair.
     */
    public enum BusStatus {
        ACTIVE, INACTIVE, MAINTENANCE
    }

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    /** Internal bus number like "UNI-001" */
    @Column(name = "bus_number", nullable = false, unique = true, length = 50)
    private String busNumber;

    /** Government registration plate like "LHR-0001" */
    @Column(name = "number_plate", nullable = false, unique = true, length = 30)
    private String numberPlate;

    /** Maximum passenger capacity */
    @Column(nullable = false)
    @Builder.Default
    private Integer capacity = 40;

    @Column(name = "bus_model", length = 100)
    private String busModel;

    /**
     * @Enumerated(EnumType.STRING):
     * Stores the enum as "ACTIVE", "INACTIVE", or "MAINTENANCE"
     * in the database — NOT as 0, 1, 2.
     * String storage is more readable and safer if enum order changes.
     */
    @Enumerated(EnumType.STRING)
    @Column(nullable = false, length = 20)
    @Builder.Default
    private BusStatus status = BusStatus.ACTIVE;

    /**
     * The route currently assigned to this bus.
     * Can be null if bus is INACTIVE or MAINTENANCE.
     */
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "route_id")
    @ToString.Exclude
    private Route route;

    @CreationTimestamp
    @Column(name = "created_at", nullable = false, updatable = false)
    private LocalDateTime createdAt;

    @UpdateTimestamp
    @Column(name = "updated_at", nullable = false)
    private LocalDateTime updatedAt;
}
