package com.university.bustracker;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;

/**
 * BusTrackerApplicationTests.java
 * ================================
 * Basic smoke test — verifies the Spring Application Context
 * loads without errors. If any bean is misconfigured or a
 * dependency is missing, this test will fail and tell you what's wrong.
 *
 * Run with: mvn test
 * Or right-click in IntelliJ → Run BusTrackerApplicationTests
 *
 * @SpringBootTest: Loads the full application context.
 * @ActiveProfiles("test"): Would load application-test.properties if present.
 */
@SpringBootTest
class BusTrackerApplicationTests {

    /**
     * This test passes if the Spring context starts up successfully.
     * No assertions needed — a startup failure throws an exception.
     */
    @Test
    void contextLoads() {
        // If we reach this line, the application context started correctly.
        System.out.println("✅ Spring Application Context loaded successfully!");
    }
}
