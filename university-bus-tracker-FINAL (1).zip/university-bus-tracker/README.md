# 🚌 University Bus Tracking System

A complete, production-quality **Live Bus Tracking System** built with:

- **Backend:** Java 17 + Spring Boot 3.2.3 + Spring Security (JWT)
- **Database:** MySQL 8 + JPA/Hibernate
- **Frontend:** Vanilla HTML + CSS + JavaScript
- **Maps:** Leaflet.js (OpenStreetMap)
- **Build Tool:** Maven

---

## 📁 Project Structure

```
university-bus-tracker/
├── pom.xml                          ← Maven dependencies
├── database/
│   └── schema.sql                   ← Full MySQL schema + sample data
└── src/
    ├── main/
    │   ├── java/com/university/bustracker/
    │   │   ├── BusTrackerApplication.java     ← Entry point
    │   │   ├── config/
    │   │   │   ├── SecurityConfig.java         ← JWT + role-based auth
    │   │   │   └── WebConfig.java              ← Static file routing
    │   │   ├── controller/                     ← REST API endpoints
    │   │   │   ├── AuthController.java         ← /api/auth/**
    │   │   │   ├── BusController.java          ← /api/buses/**
    │   │   │   ├── RouteController.java        ← /api/routes/**
    │   │   │   ├── LocationController.java     ← /api/location/**
    │   │   │   ├── AdminController.java        ← /api/admin/**
    │   │   │   ├── DriverController.java       ← /api/driver/**
    │   │   │   └── StudentController.java      ← /api/student/**
    │   │   ├── model/                          ← JPA entities (DB tables)
    │   │   │   ├── Student.java
    │   │   │   ├── Driver.java
    │   │   │   ├── Admin.java
    │   │   │   ├── Bus.java
    │   │   │   ├── Route.java
    │   │   │   ├── RouteStop.java
    │   │   │   ├── BusLocation.java
    │   │   │   ├── Trip.java
    │   │   │   └── Notification.java
    │   │   ├── repository/                     ← Spring Data JPA repos
    │   │   ├── service/                        ← Business logic
    │   │   ├── dto/                            ← Request/Response objects
    │   │   ├── security/                       ← JWT filter + provider
    │   │   └── exception/                      ← Error handling
    │   └── resources/
    │       ├── application.properties          ← DB + JWT config
    │       └── static/                         ← Frontend HTML pages
    │           ├── index.html
    │           ├── login.html
    │           ├── student-dashboard.html
    │           ├── driver-dashboard.html
    │           ├── admin-dashboard.html
    │           └── css/styles.css
    └── test/
        └── BusTrackerApplicationTests.java
```

---

## ⚙️ Setup Instructions

### Prerequisites
| Tool | Version | Download |
|------|---------|----------|
| Java JDK | 17+ | https://adoptium.net |
| MySQL | 8.0+ | https://dev.mysql.com/downloads |
| Maven | 3.8+ | https://maven.apache.org (or use IntelliJ bundled) |
| IntelliJ IDEA | Any | https://www.jetbrains.com/idea |

---

### Step 1 — Set Up MySQL Database

Open MySQL Workbench or terminal and run:

```bash
mysql -u root -p < database/schema.sql
```

Or paste the contents of `database/schema.sql` into MySQL Workbench and execute.

This creates:
- Database: `university_bus_tracker`
- All 8 tables with proper relationships
- Sample data (2 admins, 8 drivers, 8 buses, 8 routes, 5 students)

---

### Step 2 — Configure Database Password

Open `src/main/resources/application.properties` and update:

```properties
spring.datasource.url=jdbc:mysql://localhost:3306/university_bus_tracker?useSSL=false&serverTimezone=UTC&allowPublicKeyRetrieval=true
spring.datasource.username=root
spring.datasource.password=YOUR_MYSQL_PASSWORD_HERE
```

---

### Step 3 — Open in IntelliJ IDEA

1. Open IntelliJ IDEA
2. Click **File → Open** and select the `university-bus-tracker` folder
3. IntelliJ will detect it as a Maven project and download dependencies automatically
4. Wait for the Maven sync to complete (bottom status bar)

---

### Step 4 — Run the Application

**Option A — IntelliJ:**
- Open `BusTrackerApplication.java`
- Click the green ▶ Run button (or press `Shift+F10`)

**Option B — Terminal:**
```bash
cd university-bus-tracker
mvn spring-boot:run
```

**Option C — Build JAR and run:**
```bash
mvn clean package -DskipTests
java -jar target/bus-tracker-1.0.0.jar
```

---

### Step 5 — Open in Browser

```
http://localhost:8080
```

You'll be redirected to the login page automatically.

---

## 🔑 Demo Login Credentials

All accounts use password: **`password123`**

| Role | Email | Dashboard |
|------|-------|-----------|
| Admin | admin@university.edu | /admin-dashboard.html |
| Admin | manager@university.edu | /admin-dashboard.html |
| Driver | driver1@university.edu | /driver-dashboard.html |
| Driver | driver2@university.edu | /driver-dashboard.html |
| Student | ali@student.edu | /student-dashboard.html |
| Student | sara@student.edu | /student-dashboard.html |

---

## 📡 REST API Documentation

All API responses follow this structure:
```json
{
  "success": true,
  "message": "Description",
  "data": { }
}
```

### Authentication Endpoints (Public)

| Method | URL | Description |
|--------|-----|-------------|
| POST | `/api/auth/login` | Login (all roles) |
| POST | `/api/auth/register` | Student registration |

**Login Request:**
```json
{
  "email": "admin@university.edu",
  "password": "password123",
  "role": "ADMIN"
}
```

**Login Response:**
```json
{
  "success": true,
  "message": "Login successful",
  "data": {
    "token": "eyJhbGciOiJIUzI1NiJ9...",
    "tokenType": "Bearer",
    "userId": 1,
    "name": "Super Admin",
    "email": "admin@university.edu",
    "role": "ROLE_ADMIN",
    "expiresIn": 86400
  }
}
```

All subsequent requests must include the token in the header:
```
Authorization: Bearer eyJhbGciOiJIUzI1NiJ9...
```

---

### Bus Endpoints

| Method | URL | Auth | Description |
|--------|-----|------|-------------|
| GET | `/api/buses` | Public | Get all buses |
| GET | `/api/buses/{id}` | Public | Get bus by ID |
| GET | `/api/buses/active` | Public | Get active buses only |
| POST | `/api/buses` | Admin | Create new bus |
| PUT | `/api/buses/{id}` | Admin | Update bus |
| DELETE | `/api/buses/{id}` | Admin | Delete bus |
| POST | `/api/buses/{busId}/assign-driver/{driverId}` | Admin | Assign driver to bus |

---

### Route Endpoints

| Method | URL | Auth | Description |
|--------|-----|------|-------------|
| GET | `/api/routes` | Public | Get all routes |
| GET | `/api/routes/active` | Public | Get active routes |
| GET | `/api/routes/{id}` | Public | Get route with stops |
| POST | `/api/routes` | Admin | Create route |
| PUT | `/api/routes/{id}` | Admin | Update route |
| DELETE | `/api/routes/{id}` | Admin | Delete route |

---

### Location Endpoints (Live Tracking)

| Method | URL | Auth | Description |
|--------|-----|------|-------------|
| POST | `/api/location/update` | Driver | Send GPS coordinates |
| GET | `/api/location/bus/{busId}` | Public | Latest location of one bus |
| GET | `/api/location/all` | Public | Latest location of all buses |
| GET | `/api/location/bus/{busId}/trail` | Public | Recent location trail |

**Location Update (sent by driver every few seconds):**
```json
{
  "latitude": 31.5204,
  "longitude": 74.3587,
  "speed": 45.5,
  "heading": 180.0,
  "accuracy": 10.0,
  "tripId": 1
}
```

---

### Driver Endpoints

| Method | URL | Auth | Description |
|--------|-----|------|-------------|
| POST | `/api/driver/trip/start` | Driver | Start a trip |
| POST | `/api/driver/trip/{id}/end` | Driver | End a trip |
| GET | `/api/driver/trip/active` | Driver | Get current active trip |
| GET | `/api/driver/trip/history` | Driver | Get past trips |

---

### Admin Endpoints

| Method | URL | Auth | Description |
|--------|-----|------|-------------|
| GET | `/api/admin/dashboard` | Admin | System statistics |
| GET | `/api/admin/drivers` | Admin | All drivers |
| POST | `/api/admin/drivers` | Admin | Create driver |
| PUT | `/api/admin/drivers/{id}` | Admin | Update driver |
| DELETE | `/api/admin/drivers/{id}` | Admin | Delete driver |

---

### Student Endpoints

| Method | URL | Auth | Description |
|--------|-----|------|-------------|
| GET | `/api/student/profile` | Student | Own profile |
| GET | `/api/student/notifications` | Student | Notifications |

---

## 🗺️ How Live Tracking Works

```
Driver Browser                 Backend                    Student Browser
     │                            │                              │
     │  watchPosition() fires     │                              │
     │──POST /api/location/update─▶                              │
     │  {lat, lng, speed...}      │  Save to bus_locations table │
     │                            │                              │
     │  (every few seconds)       │                         ◀────│ GET /api/location/all
     │                            │  Return latest per bus  ─────▶
     │                            │                              │
     │                            │                         Map updates marker
```

1. Driver opens driver dashboard and clicks **Start Trip**
2. Browser requests GPS permission (`navigator.geolocation.watchPosition`)
3. Every GPS update sends coordinates to `POST /api/location/update`
4. Backend stores each ping in `bus_locations` table
5. Student map polls `GET /api/location/all` every 5 seconds
6. Leaflet.js moves the bus marker on the map

---

## 🚀 Production Deployment Checklist

1. **Change JWT secret** in `application.properties` to a strong random string
2. **Set** `spring.jpa.hibernate.ddl-auto=validate` (not `update`)
3. **Set** `spring.jpa.show-sql=false`
4. **Use environment variables** for DB password (never hardcode in production)
5. **Add HTTPS** using a reverse proxy (Nginx + Let's Encrypt)
6. **Build the JAR:** `mvn clean package -DskipTests`
7. **Run:** `java -jar target/bus-tracker-1.0.0.jar`

---

## 🐛 Common Issues & Fixes

| Problem | Fix |
|---------|-----|
| `Access denied for user 'root'@'localhost'` | Check MySQL password in `application.properties` |
| `Unknown database 'university_bus_tracker'` | Run `database/schema.sql` in MySQL first |
| `Port 8080 already in use` | Change `server.port=8081` in properties |
| `Could not autowire JwtAuthenticationFilter` | Ensure all packages are under `com.university.bustracker` |
| GPS not working on driver dashboard | Must use HTTPS in production; localhost works in development |
| Login fails with valid credentials | Check BCrypt hash in DB matches `password123` |

---

## 📱 Features Summary

### Student
- ✅ Register / Login / Logout
- ✅ View all buses with live status
- ✅ Live map showing all bus locations (Leaflet.js)
- ✅ Search buses by number or route
- ✅ View all routes with stops
- ✅ Dark / Light mode toggle
- ✅ Mobile responsive

### Driver
- ✅ Login / Logout
- ✅ Start / End trip
- ✅ Live GPS tracking (watchPosition)
- ✅ Real-time location sent to backend
- ✅ View own location on map
- ✅ Trip history
- ✅ GPS stats display (speed, heading, accuracy)

### Admin
- ✅ Dashboard with system stats
- ✅ Add / Edit / Delete buses
- ✅ Add / Edit / Delete drivers
- ✅ Assign drivers to buses
- ✅ Add / Edit / Delete routes
- ✅ View all buses in table

---

*Built for UET University — CMPE Course Project*
